﻿// This is a personal academic project. Dear PVS-Studio, please check it.
// PVS-Studio Static Code Analyzer for C, C++, C#, and Java: https://pvs-studio.com

using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
        #region Задание 1
        M1:
            try
            {
                //Задание 1
                //Ввести целое положительное число.
                //Проверить истинность высказывания: "Данное целое число является четным двузначным числом".
                Console.WriteLine("Задание 1");

                int A = 0;
                Console.WriteLine("Введите целое положительное число");
                A = Convert.ToInt32(Console.ReadLine());

                if (A >= 10 && A <= 99)
                {
                    if (A % 2 == 0)
                    {
                        Console.WriteLine("Число {0} является чётным двузначным", A);
                    }
                    else
                    {
                        Console.WriteLine("Число не удовлетворяет условию");
                    }
                }
                else
                {
                    Console.WriteLine("Число не удовлетворяет условию");
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }
            #endregion

            Console.WriteLine("");

        #region Задание 2
        M2:
            try
            {
                //Задание 2
                //Дано вещественное число A и целое число N (N > 0).
                //Вывести значение результата A в степени N: AN = A*A*...*A (число A перемножается N раз).
                Console.WriteLine("Задание 2");

                double A = 0;
                double A1 = 0;
                Console.Write("Введите вещественное число A: ");
                A = Convert.ToDouble(Console.ReadLine());
            M2_1:
                int N = 0;
                Console.Write("Введите целое положительное число N: ");
                N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    A1 = Math.Pow(A, N);
                    Console.WriteLine($"Число {A}, возведённое в степень {N} = {A1}");
                }
                else
                {
                    Console.WriteLine($"Число {N} не соответствует условию задачи");
                    goto M2_1;
                }
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }
            #endregion

            Console.WriteLine("");

        #region Задание 3

            //Задание 3
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Проверить, образует ли данный набор возрастающую последовательность.
            //Если образует, то вывести True, если нет - вывести False.
            Console.WriteLine("Задание 3");

        M3_3:
            try
            {
            M3:
                bool TRFL = true;
                int N = 0;

                Console.WriteLine("Введите число элементов массива, но не меньше 25!");
                N = Convert.ToInt32(Console.ReadLine());
                if (N < 25)
                {
                    Console.WriteLine("Число элементов массива меньше 25!");
                    goto M3;
                }
                int[] array = new int[N];
            M3_1:
                try
                {
                    Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                    int Vvod = Convert.ToInt32(Console.ReadLine());
                    switch (Vvod)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < array.Length; i++)
                            {
                                array[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < array.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            M3_2:
                                array[i] = 0;
                                try
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (OverflowException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto M3_2;
                                }
                                catch (FormatException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto M3_2;
                                }
                            }
                            break;
                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto M3_1;
                    }
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                    goto M3_1;
                }
                catch (OverflowException e)
                {
                    Console.WriteLine(e.Message);
                    goto M3_1;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }
                for (int i = 0; i < array.Length - 1; i++)
                {
                    if (array[i] > array[i + 1])
                    {
                        TRFL = false;
                        break;
                    }
                }
                Console.WriteLine("");
                Console.WriteLine(TRFL);
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M3_3;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M3_3;
            }
            #endregion

            Console.WriteLine("");

        #region Задание 4
            //Задание 4
            //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            //Длина строки может быть разной.
            //Найти и вывести все слова, начинающиеся на гласную букву.
            Console.WriteLine("Задание 4");

            Console.WriteLine("Введите любые символы:");
            string str1 = Console.ReadLine();

            string[] podcherk = str1.Split('_');
            string glasnie = "aeyuioAEYUIOяыуаеиоюэЯЫУАЕИОЮЭ";

            Console.WriteLine("Слова начинающиеся на гласную:");

            for (int i = 0; i < podcherk.Length; i++)
            {
                if (podcherk[i].Length > 0 && glasnie.Contains(podcherk[i][0]))
                {
                    Console.WriteLine(podcherk[i]);
                }
            }
            #endregion

            Console.WriteLine("");

        #region Задание 5
            //Задание 5
            //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            //Длина строки может быть разной.
            //Найти и вывести все слова, которые начинающиеся только на цифру 3 или 7.
            Console.WriteLine("Задание 5");

            Console.WriteLine("Введите любые символы:");
            string str2 = Console.ReadLine();

            string[] podcherk1 = str2.Split('_');
            string cifri = "37";

            Console.WriteLine("Слова начинающиеся на 3 или 7:");

            for (int i = 0; i < podcherk1.Length; i++)
            {
                if (podcherk1[i].Length > 0 && cifri.Contains(podcherk1[i][0]))
                {
                    Console.WriteLine(podcherk1[i]);
                }
            }
            #endregion

        Console.WriteLine("Нажмите любую клавишу чтобы закрыть консоль");
        Console.ReadLine();
        }
    }
}