﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_05
{
    class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            //Даны три целых числа: A, B, C.
            //Проверить истинность высказывания: «Ровно два из чисел A, B, C являются положительными».
            Console.WriteLine("Задание 1");
            Console.WriteLine("Проверка истинности высказывания: «Ровно два из чисел A, B, C являются положительными");
        M1:
            try
            {

                bool  bool1= false;

                int A = 0;
                Console.WriteLine("Введите целое число A");
                A = Convert.ToInt32(Console.ReadLine());

                int B = 0;
                Console.WriteLine("Введите целое число B");
                B = Convert.ToInt32(Console.ReadLine());

                int C = 0;
                Console.WriteLine("Введите целое число C");
                C = Convert.ToInt32(Console.ReadLine());

                if (A > 0 && B > 0 && C < 0)
                {
                    Console.WriteLine("Числа A и B положительные, а C нет");
                    bool1 = true;
                }
                if (A > 0 && B < 0 && C > 0)
                {
                    Console.WriteLine("Числа A и C положительные, а B нет");
                    bool1 = true;
                }
                if (A < 0 && B > 0 && C > 0)
                {
                    Console.WriteLine("Числа B и C положительные, а A нет");
                    bool1 = true;
                }
                if (bool1 == false)
                {
                    Console.WriteLine("Высказывание не истинно");
                }
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }

            Console.WriteLine("");

            //Задание 2
            //Даны два целых положительных числа A и B (A < B).
            //Найти произведение всех нечетных чисел расположенных между этими числами A и B.
            Console.WriteLine("Задание 2");

            M2_2:
            try
            {
            M2_1:
                Console.WriteLine("Введите два целых положительных числа A и B, причём A < B");
                bool bool2 = false;
                int A1 = 0;
                Console.WriteLine("Введите число A");
                A1 = Convert.ToInt32(Console.ReadLine());

                int B1 = 0;
                Console.WriteLine("Введите число B");
                B1 = Convert.ToInt32(Console.ReadLine());

                if (A1 < B1)
                {
                    bool2 = true;
                }
                if (bool2 == false)
                {
                    Console.WriteLine("Условие не выполняется!");
                    goto M2_1;
                }
                bool proizvedBool = false;
                int proizved = 1;
                for (int i = A1 +1;i < B1; i++)
                {
                    if (i % 2 != 0)
                    {
                        proizved *= i;
                        proizvedBool = true;
                    }
                }
                if (proizvedBool == true)
                {
                    Console.WriteLine("Произведение нечётных чисел равно = {0}", proizved);
                }
                else
                {
                    Console.WriteLine("Нечётных чисел не обнаружено");
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M2_2;
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M2_2;
            }

            Console.WriteLine("");

            //Задание 3
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Если в наборе имеются отрицательные нечетные числа,
            //то найти сумму всех положительных четных чисел,
            //иначе вычислить сумму всех чисел, которые кратные числу 5.
            Console.WriteLine("Задание 3");

        M3_1:
            try
            {
            int N = 0;

            Console.WriteLine("Введите число элементов массива, но не меньше 25!");
            N = Convert.ToInt32(Console.ReadLine());
            if (N < 25)
            {
                Console.WriteLine("Число элементов массива меньше 25!");
                goto M3_1;
            }
            int[] array = new int[N];

        M3_2:
                Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                int Vvod = Convert.ToInt32(Console.ReadLine());
                switch (Vvod)
                {
                    case 1:
                        Random rand = new Random();
                        for (int i = 0; i < array.Length; i++)
                        {
                            array[i] = rand.Next(-50, 50);
                        }
                        break;
                    case 2:
                        for (int i = 0; i < array.Length; i++)
                        {

                            Console.Write("Введите число {0}: ", i + 1);
                        M3_3:
                            array[i] = 0;
                            try
                            {
                                array[i] = Convert.ToInt32(Console.ReadLine());
                            }
                            catch (OverflowException e)
                            {
                                Console.WriteLine(e.Message);
                                goto M3_3;
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine(e.Message);
                                goto M3_3;
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("Введено неверное значение!");
                        goto M3_2;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }

                Console.WriteLine("");

                bool bool3_1 = false;
                int sum1 = 0;
                int sum2 = 0;
                for (int i = 0; i< array.Length; i++)
                {
                    if (array[i] % 2 != 0 && array[i] < 0)
                    {
                        bool3_1 = true;
                        break;
                    }
                }
                if (bool3_1 == true)
                {
                    for (int i = 0; i<array.Length; i++)
                    {
                        if(i > 0 && i % 2 == 0)
                        {
                            sum1 += array[i];
                        }
                    }
                }
                if (bool3_1 == false)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (i % 5 == 0)
                        {
                            sum2 += array[i];
                        }
                    }
                }
                if (bool3_1 == true)
                {
                    Console.WriteLine("Сумма всех положительных чётных чисел = {0}", sum1);
                }
                if (bool3_1 == false)
                {
                    Console.WriteLine("Сумма всех чисел которые кратны 5 = {0}", sum2);
                }
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M3_1;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M3_1;
            }

            Console.WriteLine("Нажмите на любую клавишу");
            Console.ReadLine();

            //Задание 4
            //Вводится строка.
            //Длина строки может быть разной.
            //Заменить на символ '%' (процент) каждый второй символ исходной строки.
            //Вывести полученную строку и общее количество замен этих символов.

            //string str = "";
            //Console.WriteLine("Введите любые символы");
            //str = Console.ReadLine();

            //Char[] chararray = str.ToCharArray();
            //for (int i = 1; i < chararray.Length; i++)
            //{
            //    ;
            //}
        }
    }
}
