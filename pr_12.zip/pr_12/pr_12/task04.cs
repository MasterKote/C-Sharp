﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task04
    {
        public int chK;

        public task04(int K)
        {
            chK = K;
        }

        public bool IsSquare(int K)
        {
            double check = Convert.ToDouble(K);
            double checkk = Math.Sqrt(check);
            if ((checkk * checkk) % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
