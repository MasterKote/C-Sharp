﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task03
    {
        public int[] massive;

        public task03(int []array)
        {
            massive = array;
        }

        public int calculatingMassive()
        {
            int sum = 0;
            Console.WriteLine("");
            for (int i = 0; i < massive.Length; i++)
            {
                if (massive[i] > 0 && massive[i] %2 != 0)
                {
                    Console.Write(massive[i] + " ");
                    sum += massive[i];
                }
            }
            Console.WriteLine("");
            Console.WriteLine("Сумма положительных нечётных цифр = {0}", sum);
            if (sum == 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
