﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task02
    {
        public int chN;

        public task02(int N_zad2)
        {
            chN = N_zad2;
        }

        public int SummOfDigits()
        {
            int digit1 = chN / 10000;
            int digit2 = chN / 1000 % 10;
            int digit3 = chN / 100 % 10;
            int digit4 = chN / 10 % 10;
            int digit5 = chN % 10;
            return digit1 + digit2 + digit3 + digit4 + digit5;
        }
    }
}
