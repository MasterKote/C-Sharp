﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            M1:
            try
            {
                //Задание 1
                //Даны три целых числа: A, B, C.
                //Проверить истинность высказывания: "Число B находится между числами A и C".
                Console.WriteLine("Задание 1");

                Console.WriteLine("Введите целое число A");
                int A_zad1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число B");
                int B_zad1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число C");
                int C_zad1 = Convert.ToInt32(Console.ReadLine());

                task01 zadanie1 = new task01(A_zad1, B_zad1, C_zad1);
                bool check = zadanie1.Output();
                if (check == true)
                {
                    Console.WriteLine("Число B({0}) находится между числа A({1}) и B({2})", B_zad1, A_zad1, C_zad1);
                }
                else
                {
                    Console.WriteLine("Число B({0}) НЕ находится между числа A({1}) и B({2})", B_zad1, A_zad1, C_zad1);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }

            Console.WriteLine("");

            M2:
            try
            {
                //Задание 2
                //Дано целое положительное пятизначное число N(N > 0).
                //Используя операции деления и определения остатка от деления найти и вывести сумму всех его цифр.
                Console.WriteLine("Задание 2");

            zad2_m1:
                Console.WriteLine("Введите целое положительное пятизначное число N");
                int N_zad2 = Convert.ToInt32(Console.ReadLine());
                if (N_zad2 >= 10000 && N_zad2 <= 99999)
                {
                    task02 summofdigits = new task02(N_zad2);
                    Console.WriteLine("Сумма цифр числа N = {0}, равна = {1}", N_zad2, summofdigits.SummOfDigits());
                }
                else
                {
                    Console.WriteLine("Число вне диапазона!");
                    goto zad2_m1;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }

            Console.WriteLine("");

            M3:
            try
            {
                //Задание 3
                //Дан массив ненулевых целых чисел, признак его завершения - число 0.
                //Вывести на экран все положительные нечётные числа из данного набора,
                //а строкой ниже вывести их сумму.
                //Если требуемые числа в наборе отсутствуют, то вывести значение -1.
                Console.WriteLine("Задание 3");

            Massive1:
                Console.WriteLine("Введите число элементов не менее 30");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N < 30)
                {
                    Console.WriteLine("В массиве должно быть не менее 30 элементов!");
                    goto Massive1;
                }
                int[] array = new int[N];
            Mmas:
                try
                {
                    Console.WriteLine("Выберите как хотите заполнимать массив, 1 - автоматически, 2 - ручной ввод");
                    int switchcs = Convert.ToInt32(Console.ReadLine());
                    switch (switchcs)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < array.Length; i++)
                            {
                                array[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < array.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            Mmmas:
                                array[i] = 0;
                                try
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto Mmmas;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto Mmas;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto Mmas;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }
                task03 task_array = new task03(array);
                int output = task_array.calculatingMassive();
                if (output == 1)
                {
                    Console.WriteLine("-1");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }

            Console.WriteLine("");

            M4:
            try
            {
                //Задание 4
                //Написать функцию bool IsSquare(K) логического типа,
                //возвращающую True,
                //если целый параметр K (K > 0) является квадратом некоторого целого числа,
                //и False в противном случае.
                Console.WriteLine("Задание 4");

            M_zad4:
                Console.WriteLine("Введите целое число K");
                int K = Convert.ToInt32(Console.ReadLine());
                if (K > 0)
                {
                    task04 output4 = new task04(K);
                    Console.WriteLine(output4.IsSquare(K));
                }
                else
                {
                    Console.WriteLine("Число должно быть больше 0!");
                    goto M_zad4;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M4;
            }

            Console.WriteLine("");

            M5:
            try
            {
                //Задание 5
                //Вводится строка, изображающая десятичную запись целого положительного числа.
                //Вывести строку, изображающую двоичную запись этого же числа.
                Console.WriteLine("Задание 5");

            M_zad5:
                Console.WriteLine("Введите целое положительное число");
                string str = Console.ReadLine();
                if (int.TryParse(str, out int number) && number > 0)
                {
                    task05 dvoichzap = new task05(number);
                    Console.WriteLine("Двоичная запись число = {0}, равна = {1}", number, dvoichzap.dvoichzapis());
                }
                else
                {
                    Console.WriteLine("Обнаружены прочие символы!");
                    goto M_zad5;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M5;
            }
        }
    }
}
