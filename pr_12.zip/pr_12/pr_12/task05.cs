﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task05
    {
        int number1;

        public task05(int number)
        {
            number1 = number;
        }

        public string dvoichzapis()
        {
            string dvoich = Convert.ToString(number1, 2);
            return dvoich;
        }
    }
}
