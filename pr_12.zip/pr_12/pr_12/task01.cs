﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task01
    {
        public int chA;
        public int chB;
        public int chC;

        public task01(int A_zad1, int B_zad1, int C_zad1)
        {
            this.chA = A_zad1;
            this.chB = B_zad1;
            this.chC = C_zad1;
        }

        public bool Output()
        {
            if (chA > chB && chB > chC)
            {
                return true;
            }
            else if(chA < chB && chB < chC)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
