﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace pr_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            унитаз1:
            try
            {
                //Задание 1
                Console.WriteLine("Задание 1");

            унитаз:
                Console.Write("Введите четырёхзначное в убывающей последовательности положительное число: ");
                int ch1 = 0;
                int ch2 = 0;
                int ch3 = 0;
                int ch4 = 0;
                int a = 0;
                a = Convert.ToInt32(Console.ReadLine());

                if (a >= 1000 & a <= 9999)
                {
                    ch1 = a / 1000;
                    ch2 = a / 100 % 10;
                    ch3 = a / 10 % 10;
                    ch4 = a % 10;
                }
                else
                {
                    Console.WriteLine("Введено число вне диапазона!!!");
                    goto унитаз;
                }
                if (ch2 < ch1)
                {
                    if (ch3 < ch2)
                    {
                        if (ch4 < ch3)
                        {
                            Console.WriteLine("Цифры числа образуют убывающую последовательность");
                        }
                        else
                        {
                            Console.WriteLine("Цифры числа НЕ образуют убывающую последовательность");
                            goto унитаз;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Цифры числа НЕ образуют убывающую последовательность");
                        goto унитаз;
                    }
                }
                else
                {
                    Console.WriteLine("Цифры числа НЕ образуют убывающую последовательность");
                    goto унитаз;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto унитаз1;
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto унитаз1;
            }

            Console.WriteLine();

            бензопила1:
            try
            {
                //Задание 2
                Console.WriteLine("Задание 2");

                double A = 0;
                double A1 = 0;
                Console.Write("Введите вещественное число A: ");
                A = Convert.ToDouble(Console.ReadLine());
            бензопила:
                int N = 0;
                Console.Write("Введите целое положительное число N: ");
                N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    A1 = Math.Pow(A, N);
                    Console.WriteLine($"Число {A}, возведённое в степень {N} = {A1}");
                }
                else
                {
                    Console.WriteLine($"Число {N} не соответствует условию задачи");
                    goto бензопила;
                }
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto бензопила1;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto бензопила1;
            }

            Console.WriteLine() ;

            амням:
            try
            {
                //Задание 3
                Console.WriteLine("Задание 3");

            холодильник:

                int N1 = 0;

                Console.WriteLine("Введите число элементов массива, но не меньше 25!");
                N1 = Convert.ToInt32(Console.ReadLine());
                if (N1 < 25)
                {
                    Console.WriteLine("Число элементов массива меньше 25!");
                    goto холодильник;
                }
                int[] array = new int[N1];
            круг:
                try
                {
                Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                int Vvod = Convert.ToInt32(Console.ReadLine());
                    switch (Vvod)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < array.Length; i++)
                            {
                                array[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < array.Length; i++)
                            {
                                Console.Write("Введите число {0}: ", i + 1);
                            pifpaf:
                                array[i] = 0;
                                try
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (OverflowException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto pifpaf;
                                }
                                catch (FormatException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto pifpaf;
                                }
                            }
                            break;
                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto круг;
                    }
                }
                catch (OverflowException e)
                {
                    Console.WriteLine(e.Message);
                    goto круг;
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                    goto круг;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }

                Console.WriteLine();

                int summmmm = 0;
                int sum5 = 0;
                bool EstOtricChisla = false;
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] < 0 && array[i] % 2 != 0)
                    {
                        EstOtricChisla = true;
                    }
                }

                if (EstOtricChisla == true)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] > 0 && array   [i] % 2 == 0)
                        {
                            summmmm += array[i];
                        }
                    }
                }
                if (EstOtricChisla == false)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] % 5 == 0)
                        {
                            sum5 += array[i];
                        }
                    }
                }
                Console.WriteLine("Сумма всех положительный чётных чисел = {0}", summmmm);
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto амням;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto амням;
            }

            Console.WriteLine();

            //Задание 4
            Family:
            try
            {
                Console.WriteLine("Задание 4");

            Jawa350cc:

                int N2 = 0;

                Console.WriteLine("Введите число элементов массива, но не меньше 25!");
                N2 = Convert.ToInt32(Console.ReadLine());
                if (N2 < 25)
                {
                    Console.WriteLine("Число элементов массива меньше 25!");
                    goto Jawa350cc;
                }
                int[] араэ = new int[N2];
            МихаилКруг:
                try
                {
                    Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                    int Vvod = Convert.ToInt32(Console.ReadLine());
                    switch (Vvod)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < араэ.Length; i++)
                            {
                                араэ[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < араэ.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            fwef:
                                араэ[i] = 0;
                                try
                                {
                                    араэ[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (OverflowException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto fwef;
                                }
                                catch (FormatException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto fwef;
                                }
                            }
                            break;
                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto МихаилКруг;
                    }
                }
                catch (OverflowException e)
                {
                    Console.WriteLine(e.Message);
                    goto МихаилКруг;
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                    goto МихаилКруг;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < араэ.Length; i++)
                {
                    Console.Write(араэ[i] + " ");
                }

                Console.WriteLine();

                bool booispugalsa = true;

                for (int i = 0; i < араэ.Length; i++)
                {
                    if (араэ[i] <= 0 || араэ[i] % 2 != 0)
                    {
                        booispugalsa = false;
                        break;
                    }
                }
                Console.WriteLine(booispugalsa);
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto Family;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto Family;
            }

        //Задание 5
        утка:
            try
            {
                Console.WriteLine("Задание 5");

            HusqvarnaFE250:

                int N3 = 0;

                Console.WriteLine("Введите число элементов массива, но не меньше 25!");
                N3 = Convert.ToInt32(Console.ReadLine());
                if (N3 < 25)
                {
                    Console.WriteLine("Число элементов массива меньше 25!");
                    goto HusqvarnaFE250;
                }

                заного:
                bool allisgood = false;
                int L = 0;
                Console.Write("Введите число L <= N и L >= K: ");
                L = Convert.ToInt32(Console.ReadLine());
                int K = 0;
                Console.Write("Введите число K <= L и K >= 1: ");
                K = Convert.ToInt32(Console.ReadLine());

                if (L <= N3 && L >= K)
                {
                    allisgood = true;
                }
                else
                {
                    allisgood = false;
                }

                if (K <= L && K >= 1)
                {
                    allisgood = true;
                }
                else
                {
                    allisgood = false;
                }

                if (allisgood == false)
                {
                    Console.WriteLine("Условие не выполняется!!!!!");
                    goto заного;
                }

                int[] андрей = new int[N3];
            Бутырка:
                try
                {
                    Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                    int Vvod = Convert.ToInt32(Console.ReadLine());
                    switch (Vvod)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < андрей.Length; i++)
                            {
                                андрей[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < андрей.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            fwef:
                                андрей[i] = 0;
                                try
                                {
                                    андрей[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (OverflowException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto fwef;
                                }
                                catch (FormatException e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto fwef;
                                }
                            }
                            break;
                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto Бутырка;
                    }
                }
                catch (OverflowException e)
                {
                    Console.WriteLine(e.Message);
                    goto Бутырка;
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                    goto Бутырка;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < андрей.Length; i++)
                {
                    Console.Write(андрей[i] + " ");
                }

                Console.WriteLine();
                
                if (allisgood == true);
                {
                    double summa = 0;
                    int schet = 0;

                    for (int i = K - 1; i < L; i++)
                    {
                        summa += андрей[i];
                        schet++;
                    }

                    double среднеезнач = summa / schet;

                    Console.WriteLine("Среднее арифметическое: " + среднеезнач);
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto утка;
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto утка;
            }
            Console.WriteLine("Нажмите любую клавишу");
            Console.ReadKey();
        }
    }
}
