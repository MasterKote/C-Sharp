﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task03
    {
        public int Min4(int A, int B, int C, int D)
        {
            return Math.Min(A, Math.Min(B, Math.Min(C, D)));
        }
    }
}
