﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using var25;

namespace pr_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            //Дано целое число N (N > 0).
            //Если N - нечетное, то вывести произведение нечетных чисел до этого числа (1*3*5*N);
            //если N - четное, то вывести произведение четных чисел до этого числа (2*4*6*N).
            //Чтобы избежать целочисленного переполнения, вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число.
            //(Пример, 6=2*4*6; 9=1*3*5*7*9).
            M1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.WriteLine("Введите целое число N");
                int N1 = Convert.ToInt32(Console.ReadLine());
                task01 task1 = new task01();
                if (N1 > 0)
                {
                    if (N1 % 2 == 0)
                    {
                        double proizv = task1.Proizvedenie(N1);
                        Console.WriteLine("Произведение чётных чисел = {0}", proizv);
                    }
                    else
                    {
                        double proizv = task1.Proizvedenie(N1);
                        Console.WriteLine("Произведение нечётных чисел = {0}", proizv);
                    }
                }
                else
                {
                    Console.WriteLine("Число должно быть больше 0!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }

            Console.WriteLine("");

            //Задание 2
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Найти и вывести количество элементов,
            //расположенных после самого последнего максимального элемента.
            M2:
            try
            {
                Console.WriteLine("Задание 2");

            Massive1:
                Console.WriteLine("Введите число элементов не менее 30");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N < 30)
                {
                    Console.WriteLine("В массиве должно быть не менее 30 элементов!");
                    goto Massive1;
                }
                int[] array = new int[N];
            Mmas:
                try
                {
                    Console.WriteLine("Выберите как хотите заполнимать массив, 1 - автоматически, 2 - ручной ввод");
                    int switchcs = Convert.ToInt32(Console.ReadLine());
                    switch (switchcs)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < array.Length; i++)
                            {
                                array[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < array.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            Mmmas:
                                array[i] = 0;
                                try
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto Mmmas;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto Mmas;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto Mmas;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }
                Console.WriteLine("");
                task02 task2 = new task02();
                Console.WriteLine("Число элементов после максимального = {0}", task2.KolvoMax(array));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }

            Console.WriteLine("");

            //Задание 3
            //Написать функцию int Min4(A, B, C, D) целого типа,
            //возвращающую одно минимальное значение из 4-х своих аргументов (параметры A, B, C и D - целые числа).
            M3:
            try
            {
                Console.WriteLine("Задание 3");

                Console.WriteLine("Введите целое число A");
                int A = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число B");
                int B = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число C");
                int C = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число D");
                int D = Convert.ToInt32(Console.ReadLine());

                task03 task3 = new task03();
                Console.WriteLine("Минимальное значение из 4-х чисел = {0}", task3.Min4(A, B, C, D));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }

            Console.WriteLine("");

        //Задание 4
        //Написать функцию double Mean(X, Y),
        //вещественного типа,
        //вычисляющую среднее арифметическое двух положительных целых чисел X и Y по формуле (X+Y)/2.
        M4:
            try
            {
                Console.WriteLine("Задание 4");
            M4_1:
                Console.WriteLine("Введите положительное целое число X");
                int X4 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите положительное целое число Y");
                int Y4 = Convert.ToInt32(Console.ReadLine());
                if (X4 > 0 && Y4 > 0)
                {
                    task04 task4 = new task04();
                    Console.WriteLine("Среднеарифметическое чисел X({0}) и Y({1}) = {2}", X4, Y4, task4.Mean(X4, Y4));
                }
                else
                {
                    Console.WriteLine("Число или числа не положительные");
                    goto M4_1;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M4;
            }

            Console.WriteLine("");

            //Задание 5
            //Вводится строка, содержащая латинские буквы и круглые скобки.
            //Длина строки может быть разной.
            //Если скобки расставлены правильно
            //(т. е. каждой открывающей скобки соответствует одна закрывающая скобка),
            //то вывести число 0.
            //В противном случае вывести или номер позиции,
            //в которой расположена первая ошибочная закрывающая скобка,
            //или, если закрывающих скобок не хватает, значение −1.
            M5:
            try
            {
                Console.WriteLine("Задание 5");

                Console.WriteLine("Введите строку с латинскими буквами и скобками:");
                string str = Console.ReadLine();

                task05 task5 = new task05();
                int result = task5.StrokaCheck(str);

                if (result == 0)
                {
                    Console.WriteLine("0");
                }
                else if (result == -1)
                {
                    Console.WriteLine("-1");
                }
                else
                {
                    Console.WriteLine($"{result} (Ошибка в позиции {result})");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M5;
            }
        }
    }
}
