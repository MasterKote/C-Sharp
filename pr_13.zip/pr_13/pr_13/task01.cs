﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task01
    {
        public double Proizvedenie(int N1)
        {
            double proizved = 1;
            if (N1 % 2 == 0)
            {
                for (int i = 2; i <= N1; i += 2)
                {
                    proizved *= i;
                }
            }
            else
            {
                for (int i = 1; i <= N1; i += 2)
                {
                    proizved *= i;
                }
            }
            return proizved;
        }

        public double Proizvedenie(double N1)
        {
            double proizved = 1;
            if (N1 % 2 == 0)
            {
                for (int i = 2; i <= N1; i += 2)
                {
                    proizved *= i;
                }
            }
            else
            {
                for (int i = 1; i <= N1; i += 2)
                {
                    proizved *= i;
                }
            }
            return proizved;
        }

        public double Proizvedenie(float N1)
        {
            double proizved = 1;
            if (N1 % 2 == 0)
            {
                for (int i = 2; i <= N1; i += 2)
                {
                    proizved *= i;
                }
            }
            else
            {
                for (int i = 1; i <= N1; i += 2)
                {
                    proizved *= i;
                }
            }
            return proizved;
        }
    }
}
