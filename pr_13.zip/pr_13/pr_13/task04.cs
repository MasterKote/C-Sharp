﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task04
    {
        public double Mean(int X, int Y)
        {
            return (X + Y) / 2;
        }
    }
}
