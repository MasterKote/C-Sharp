﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task02
    {
        public int KolvoMax(int[] array)
        {
            int maxElement = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] > maxElement)
                {
                    maxElement = array[i];
                }
            }
            int IndexMaxElement = Array.IndexOf(array, maxElement);
            int kolvo = 0;
            for (int i = IndexMaxElement +1; i < array.Length; i++)
            {
                kolvo++;
            }
            return kolvo;
        }
    }
}
