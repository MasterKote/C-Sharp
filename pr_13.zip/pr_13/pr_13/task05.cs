﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task05
    {
        public int StrokaCheck(string input)
        {
            int[] stroka = new int[input.Length];
            int strokatochka = -1;

            for (int i = 0; i < input.Length; i++)
            {
                char c = input[i];

                if (c == '(')
                {
                    strokatochka++;
                    stroka[strokatochka] = i;
                }
                else if (c == ')')
                {
                    if (strokatochka == -1)
                    {
                        return i + 1;
                    }
                    strokatochka--;
                }
            }

            if (strokatochka != -1)
            {
                return -1;
            }

            return 0;
        }
    }
}
