﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Пересчет расстояния из миль в километры
            Console.WriteLine("Расчёт расстояния из миль в километры");
            Console.WriteLine("Введите расстояние в милях:");

            //Задаём переменную и конвертируем
            double a = Convert.ToDouble(Console.ReadLine());

            //Подсчёты
            double b = a * 1.605;

            //Вывод
            Console.WriteLine("{0} миль(и) - это {1} километров",a,b);


            //Вычисление объема параллелепипеда
            Console.WriteLine("Вычисление объёма параллелепипеда");
            //Ввод данных
            Console.WriteLine("Введите длину(см)");
            double z = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите ширину(см)");
            double x = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите высоту(см)");
            double c = Convert.ToDouble(Console.ReadLine());

            //Вычисление объёма
            double V = z * x * c;

            //Вывод
            Console.WriteLine("Объём: {0} куб.см.", V);


            //Вычисление площади поверхности цилиндра
            Console.WriteLine("Вычисление площади поверхности цилиндра");
            //Ввод данных
            Console.WriteLine("Введите радиус основания (см)");
            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите высоту цилиндра (см)");
            double h = Convert.ToDouble(Console.ReadLine());

            //Вычисление площади
            double S = 2 * Math.PI * r * (r + h);

            //Вывод
            Console.WriteLine("Площадь поверхности цилиндра: {0} кв.см.", S);

            //Выход
            Console.WriteLine("НАЖМИТЕ ЛЮБУЮ КНОПКУ ДЛЯ ОСТАНОВКИ");
            Console.ReadKey();
        }
    }
}
