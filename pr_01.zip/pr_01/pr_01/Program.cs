﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Пересчет расстояния из миль в километры

            Console.WriteLine("Введите расстояние в милях:");

            //Задаём переменную и конвертируем
            double a = Convert.ToDouble(Console.ReadLine());

            //Подсчёты
            double b = a * 1.605;

            //Вывод
            Console.WriteLine("{0} миль(и) - это {1} километров",a,b);

            //Выход
            Console.WriteLine("НАЖМИТЕ ЛЮБУЮ КНОПКУ ДЛЯ ОСТАНОВКИ");
            Console.ReadKey();
        }
    }
}
