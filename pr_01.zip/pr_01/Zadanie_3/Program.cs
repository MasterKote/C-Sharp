﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Вычисление площади поверхности цилиндра

            //Ввод данных
            Console.WriteLine("Введите радиус основания (см)");
            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите высоту цилиндра (см)");
            double h = Convert.ToDouble(Console.ReadLine());

            //Вычисление площади
            double S = 2 * Math.PI * r * (r + h);

            //Вывод
            Console.WriteLine("Площадь поверхности цилиндра: {0} кв.см.",S);

            //Выход
            Console.WriteLine("НАЖМИТЕ ЛЮБУЮ КНОПКУ ДЛЯ ОСТАНОВКИ");
            Console.ReadKey();
        }
    }
}
