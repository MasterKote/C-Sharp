﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Вычисление объема параллелепипеда

            //Ввод данных
            Console.WriteLine("Введите длину(см)");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите ширину(см)");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите высоту(см)");
            double c = Convert.ToDouble(Console.ReadLine());

            //Вычисление объёма
            double V = a * b * c;

            //Вывод
            Console.WriteLine("Объём: {0} куб.см.", V);

            //Выход
            Console.WriteLine("НАЖМИТЕ ЛЮБУЮ КНОПКУ ДЛЯ ОСТАНОВКИ");
            Console.ReadKey();
        }
    }
}
