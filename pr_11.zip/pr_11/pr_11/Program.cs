﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            M1:
            try
            {
                //Задание 1
                //Даны ненулевые числа x, y.
                //Проверить истинность высказывания:
                //«Точка с координатами (x, y) лежит во второй или четвертой координатной четверти».
                Console.WriteLine("Задание 1");

            x1:
                Console.WriteLine("Введите ненулевое число x");
                double x = Convert.ToDouble(Console.ReadLine());
                if (x == 0)
                {
                    Console.WriteLine("Число должно быть ненулевым!");
                    goto x1;
                }
            y1:
                Console.WriteLine("Введите ненулевое число y");
                double y = Convert.ToDouble(Console.ReadLine());
                if (y == 0)
                {
                    Console.WriteLine("Число должно быть ненулевым!");
                    goto y1;
                }

                task01 coordinatos = new task01(x, y);
                if (coordinatos.VivodOS() == 2)
                {
                    Console.WriteLine("Точка с координатами ({0}, {1}) лежит во второй координатной четверти", x, y);
                }
                else if (coordinatos.VivodOS() == 4)
                {
                    Console.WriteLine("Точка с координатами ({0}, {1}) лежит в четвёртой координатной четверти", x, y);
                }
                else
                {
                    Console.WriteLine("Точка с координатами ({0}, {1}) не лежит во второй или четвертой координатной четверти", x, y);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }

            Console.WriteLine("");

            M2:
            try
            {
                //Задание 2
                //С некоторого момента прошло N недель (N > 0).
                //Сколько полных дней прошло за этот период?
                Console.WriteLine("Задание 2");

            n1:
                Console.WriteLine("Введите сколько прошло недель с определённого момента");
                int nedeli = Convert.ToInt32(Console.ReadLine());
                if (nedeli <= 0)
                {
                    Console.WriteLine("Введите верное кол-во недель!");
                    goto n1;
                }

                task02 days = new task02(nedeli);
                Console.WriteLine("Полных дней прошло с того момента = {0}", days.vivod2());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }

            Console.WriteLine("");

            M3:
            try
            {
                //Задание 3
                //Дан целочисленный массив, состоящий из N элементов (N > 0).
                //Найти и вывести количество элементов,
                //расположенных после самого последнего максимального элемента.
                Console.WriteLine("Задание 3");

            Massive1:
                Console.WriteLine("Введите число элементов не менее 25");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N < 25)
                {
                    Console.WriteLine("В массиве должно быть не менее 25 элементов!");
                    goto Massive1;
                }
                int[] array = new int[N];
            Mmas:
                try
                {
                    Console.WriteLine("Выберите как хотите заполнимать массив, 1 - автоматически, 2 - ручной ввод");
                    int switchcs = Convert.ToInt32(Console.ReadLine());
                    switch (switchcs)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < array.Length; i++)
                            {
                                array[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < array.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            Mmmas:
                                array[i] = 0;
                                try
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto Mmmas;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto Mmas;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto Mmas;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }
                task03 maxelements = new task03(array);
                Console.WriteLine("Количество элементов после последнего максимального элемента = {0}", maxelements.vivod3());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }

            Console.WriteLine("");

            M4:
            try
            {
                //Задание 4
                //Написать функцию int SumOfSquares(A, B) целого типа,
                //находящую сумму квадратов всех целых чисел в диапазоне от A до B.
                //Если A > B, то функция должна возвращать число 0.
                Console.WriteLine("Задание 4");

                Console.WriteLine("Введите целое число A");
                int A = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число B");
                int B = Convert.ToInt32(Console.ReadLine());
                if (A > B)
                {
                    Console.WriteLine("0");
                }
                else
                {
                    task04 squares = new task04(A, B);
                    Console.WriteLine("Сумма квадратов от A до B = {0}", squares.SumOfSquares(A, B));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M4;
            }
        }
    }
}
