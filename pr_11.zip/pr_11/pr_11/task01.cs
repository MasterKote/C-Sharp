﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task01
    {
        public double chX;
        public double chY;

        public task01(double x, double y)
        {
            chX = x;
            chY = y;
        }

        public int VivodOS()
        {
            if(chX < 0 && chY > 0)
            {
                return 2;
            }
            else if(chX > 0 && chY < 0)
            {
                return 4;
            }
            else
            {
                return 0;
            }
        }
    }
}
