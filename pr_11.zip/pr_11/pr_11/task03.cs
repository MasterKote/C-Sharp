﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task03
    {
        public int[] massive;

        public task03(int[] array)
        {
            massive = array;
        }

        public int vivod3()
        {
            int maxdigit = massive[0];
            int indexmaxdigit = 0;

            for (int i = 1; i < massive.Length; i++)
            {
                if (massive[i] >= maxdigit)
                {
                    indexmaxdigit = i;
                }
            }

            int count = massive.Length - indexmaxdigit -1;

            return count;
        }
    }
}
