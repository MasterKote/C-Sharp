﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task02
    {
        public int nedelicl;

        public task02(int nedeli)
        {
            nedelicl = nedeli;
        }

        public int vivod2()
        {
            return nedelicl * 7;
        }
    }
}
