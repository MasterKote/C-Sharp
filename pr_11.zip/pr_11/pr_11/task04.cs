﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task04
    {
        public int dA;
        public int dB;

        public task04(int A, int B)
        {
            dA = A;
            dB = B;
        }

        public int SumOfSquares(int dA, int dB)
        {
            int sumsquares = 0;
            for (int i = dA + 1; i < dB; i++)
            {
                sumsquares += i*i;
            }
            return sumsquares;
        }
    }
}
