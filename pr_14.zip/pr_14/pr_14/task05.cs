﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task05
    {
        public int zadanie5(string str)
        {
            string[] words = str.Split('_');

            int count = 0;

            foreach (string word in words)
            {
                int wCount = word.ToLower().Count(c => c == 'w');

                if (wCount == 1)
                {
                    count++;
                }
            }

            return count;
        }
    }
}
