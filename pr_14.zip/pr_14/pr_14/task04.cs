﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task04
    {
        public int Min2Of5Mul(int A1, int B1, int C1, int D1, int E1)
        {
            int[] array = {A1, B1, C1, D1, E1};
            Array.Sort(array);
            return array[0] * array[1];
        }
    }
}
