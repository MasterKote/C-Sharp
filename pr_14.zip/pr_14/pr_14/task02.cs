﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task02
    {
        public (string,int) zadanie2(int M)
        {
            int M1 = Math.Abs(M / 1000);
            return ("Полных тонн = ",M1);
        }
    }
}
