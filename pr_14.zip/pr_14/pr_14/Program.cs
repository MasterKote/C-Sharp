﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using var25;

namespace pr_14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            //Проверить истинность высказывания:
            //"Данное целое положительное число является нечетным трехзначным числом".
            M1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.WriteLine("Введите целое положительное число");
                int trexznachach = Convert.ToInt32(Console.ReadLine());

                task01 task01 = new task01();
                Console.WriteLine(task01.zadanie1(trexznachach));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }

            Console.WriteLine("");

            //Задание 2
            //Дана масса M (М - целое положительное число) в килограммах.
            //Используя операцию деления нацело,
            //найти количество полных тонн в ней (1 тонна = 1000 кг).
            M2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.WriteLine("Введите целое положительное число M");
                int M = Convert.ToInt32(Console.ReadLine());

                task02 task02 = new task02();
                Console.WriteLine(task02.zadanie2(M));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }

            Console.WriteLine("");

            //Задание 3
            //Написать функцию int Min3(A, B, C) целого типа,
            //возвращающую одно минимальное значение из 3-х своих аргументов (параметры A, B, C - целые числа).
            M3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.WriteLine("Введите целое число A");
                int A = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число B");
                int B = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число C");
                int C = Convert.ToInt32(Console.ReadLine());

                task03 task03 = new task03();
                Console.WriteLine("Минимальное число = " +task03.Min3(A, B, C));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }

            Console.WriteLine("");

            //Написать функцию int Min2Of5Mul(A, B, C, D, E) целого типа,
            //возвращающую произведение двух самых минимальных из 5-ти своих аргументов (параметры A, B, C, D, E - целые числа).
            M4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.WriteLine("Введите целое число A");
                int A1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число B");
                int B1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число C");
                int C1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число D");
                int D1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите целое число E");
                int E1 = Convert.ToInt32(Console.ReadLine());

                task04 task04 = new task04();
                Console.WriteLine("Произведение 2-х минимальных чисел = " + task04.Min2Of5Mul(A1, B1, C1, D1, E1));
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                goto M4;
            }

            Console.WriteLine("");

            //Задание 5
            //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            //Длина строки может быть разной.
            //Определить и вывести количество слов, которые содержат ровно одну букву 'w'.
            Console.WriteLine("Введите строку");
            string str = Console.ReadLine();

            task05 task05 = new task05();
            Console.WriteLine($"Количество слов ровно c одной w = " +task05.zadanie5(str));
        }
    }
}
