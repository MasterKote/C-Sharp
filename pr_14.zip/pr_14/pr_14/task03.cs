﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task03
    {
        public int Min3(int A, int B, int C)
        {
            return Math.Min(A, Math.Min(B, C));
        }
    }
}
