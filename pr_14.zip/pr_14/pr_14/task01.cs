﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task01
    {
        public string zadanie1(int trexznachach)
        {
            if(trexznachach >= 100 && trexznachach <= 999 && trexznachach % 2 != 0)
            {
                return "Высказывание истино";
            }
            else
            {
                return "Высказывание ложно";
            }
        }
    }
}
