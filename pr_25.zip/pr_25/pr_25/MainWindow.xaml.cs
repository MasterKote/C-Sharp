﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr_25
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //zadanie1
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int A = Convert.ToInt32(textA.Text);
                int B = Convert.ToInt32(textB.Text);
                int C = Convert.ToInt32(textC.Text);

                if (A > 0 && B <= 0 && C <= 0)
                {
                    result1.Content = true;
                }
                else if(A <= 0 && B > 0 && C <= 0)
                {
                    result1.Content = true;
                }
                else if(A <= 0 && B <= 0 && C > 0)
                {
                    result1.Content = true;
                }
                else
                {
                    result1.Content = false;
                }
            }
            catch (Exception ex)
            {
                result1.Content = ex.Message;
            }
        }
        //zadanie2
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(textN.Text);

                if (N >= 1000 && N <= 9999)
                {
                    int digit1 = (N / 1000) % 10;
                    int digit2 = (N / 100) % 10;
                    int digit3 = (N / 10) % 10;
                    int digit4 = N % 10;

                    int first = digit1 * digit2;
                    int second = digit3 * digit4;

                    result2.Content = Math.Abs(first - second);
                }
                else
                {
                    result2.Content = "Число должно быть четырёхзначное и положительное!";
                }
            }
            catch (Exception ex)
            {
                result2.Content = ex.Message;
            }
        }
        //zadanie4
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                double A = Convert.ToInt32(funcA.Text);
                double B = Convert.ToInt32(funcB.Text);
                int Op = Convert.ToInt32(funcOp.Text);
                if (A <= 0 || B <= 0)
                {
                    result4.Content = "A и B должны быть ненулевыми вещественными";
                }
                else
                {
                    result4.Content = Calc(A, B, Op);
                }
            }
            catch (Exception ex)
            {
                result4.Content = ex.Message;
            }
        }
        //zadanie5
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                string input = stroka.Text;

                char previousDigit = '\0';
                int result = 0;
                int position = 1;

                foreach (char c in input)
                {
                    if (c >= '0' && c <= '9')
                    {
                        if (previousDigit == '\0')
                        {
                            previousDigit = c;
                        }
                        else
                        {
                            if (c < previousDigit)
                            {
                                result = position;
                                break;
                            }
                            previousDigit = c;
                        }
                    }
                    position++;
                }
                result3.Content = result;
            }
            catch (Exception ex)
            {
                result3.Content = ex.Message;
            }
        }
        public static double Calc(double A, double B, int Op)
        {
            switch (Op)
            {
                case 1:
                    return A - B;
                case 2:
                    return A * B;
                case 3:
                    return A / B;
                case 4:
                    return B + A;
                default:
                    return 0;
            }
        }
    }
}
