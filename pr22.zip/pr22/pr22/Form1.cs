﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using pr22_dll;

namespace pr22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int digitzad1 = Convert.ToInt32(textBox1.Text);

                bool res1 = pr22_dll.Zadanie1.Task01(digitzad1);
                label2.Text = res1.ToString();
            }
            catch (Exception ex)
            {
                label2.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int digitAzad2 = Convert.ToInt32(textBox2.Text);
                int digitBzad2 = Convert.ToInt32(textBox4.Text);
                if (digitAzad2 >= digitBzad2)
                {
                    label4.Text = "Число А должно быть меньше числа B!!!";
                }
                else if(digitAzad2 <= 0 || digitBzad2 <= 0)
                {
                    label4.Text = "Числа должны быть положительные!!!";
                }
                else
                {
                    string res2 = pr22_dll.Zadanie2.Task02(digitAzad2, digitBzad2);
                    label4.Text = res2.ToString();
                }
            }
            catch (Exception ex1)
            {
                label4.Text = ex1.Message;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                label9.Text = "";
                int N = Convert.ToInt32(textBox5.Text);
                if (N < 25)
                {
                    label9.Text = "Количество элементов должно быть больше 25!!!";
                }
                else
                {
                    int[] array = new int[N];
                    Random rand = new Random();
                    for (int i = 0; i < array.Length; i++)
                    {
                        array[i] = rand.Next(-50, 50);
                    }

                    for (int i = 0; i < array.Length; i++)
                    {
                        label9.Text += (array[i] + " ");
                    }

                    int res3 = pr22_dll.Zadanie3.Task03(array);
                    label10.Text = "Количество различных элементов: " + res3.ToString();
                }
            }
            catch (Exception ex2)
            {
                label9.Text = ex2.Message;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int zzad4H = Convert.ToInt32(zad4H.Text);
                int zzad4M = Convert.ToInt32(zad4M.Text);
                int zzad4S = Convert.ToInt32(zad4S.Text);

                long res4 = pr22_dll.Zadanie4.TimeToSec(zzad4H, zzad4M, zzad4S);
                label15.Text = "Часы, минуты и секунды в секунды: " + res4.ToString();
            }
            catch (Exception ex3)
            {
                label15.Text = ex3.Message;
            }
        }
    }
}
