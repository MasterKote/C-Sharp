﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace pr22_dll
{
    public class Zadanie1
    {
        public static bool Task01(int digitzad1)
        {
                int dig1 = digitzad1 / 1000;
                int dig2 = (digitzad1 / 100) % 10;
                int dig3 = (digitzad1 / 10) % 10;
                int dig4 = digitzad1 % 10;
                if (dig1 != dig2 && dig1 != dig3 && dig1 != dig4 && dig2 != dig3 && dig2 != dig4 && dig3 != dig4)
                {
                    return true;
                }
                else
                {
                    return false;
                }
        }
    }

    public class Zadanie2
    {
        public static string Task02(int digitAzad2, int digitBzad2)
        {
            string multdigitsres = "";
            for (int i = digitAzad2; i <= digitBzad2; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    multdigitsres += i.ToString();
                }
            }
            return multdigitsres;
        }
    }

    public class Zadanie3
    {
        public static int Task03(int[] array)
        {
            Array.Sort(array);

            int countdigits = 1;

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] != array[i - 1])
                {
                    countdigits++;
                }
            }

            return countdigits;
        }
    }

    public class Zadanie4
    {
        public static long TimeToSec(int zzad4H, int zzad4M, int zzad4S)
        {
            long HMSintoS = (zzad4H * 3600) + (zzad4M * 60) + zzad4S;
            return HMSintoS;
        }
    }
}
