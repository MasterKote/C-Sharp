﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pr_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            //Задание 1
            //Дано целое положительное трехзначное число N(N> 0).
            //Проверить истинность высказывания: «Данное число N читается одинаково слева направо и справа налево».

            try
            {
                int A = 0;
                using (StreamReader sr = File.OpenText("Input1.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        A = Convert.ToInt32((string)input);
                    }
                }
                using (StreamWriter writer = File.CreateText("Output1.txt"))
                {
                    if (A >= 100 && A <= 999)
                    {
                        string numberSTR = A.ToString();
                        if (numberSTR[0] == numberSTR[2])
                        {
                            writer.WriteLine("Данное число {0} читается одинаково слева направо и справа налево", A);
                        }
                        else
                        {
                            writer.WriteLine("Данное число {0} читается по разному", A);
                        }
                    }
                    else
                    {
                        writer.WriteLine("Введённое число вне диапазона!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion

            #region Задание 2
            //Задание 2
            //Дано целое положительное трехзначное число.
            //В нем зачеркнули первую справа цифру и приписали ее слева.
            //Вывести полученное новое число.

            try
            {
                int A2 = 0;
                using (StreamReader sr = File.OpenText("Input2.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        A2 = Convert.ToInt32((string)input);
                    }
                }
                using (StreamWriter writer = File.CreateText("Output2.txt"))
                {
                    if (A2 >= 100 && A2 <= 999)
                    {
                        int lastNum = A2 % 10;
                        int newNum = A2 / 10;
                        newNum = lastNum * 100 + newNum;

                        writer.WriteLine("Число наоборот {0}", newNum);
                    }
                    else
                    {
                        writer.WriteLine("Введённое число вне диапазона!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion

            #region Задание 3
            //Задание 3
            //Дан массив ненулевых целых чисел, признак его завершения - число 0.
            //Вывести на экран все положительные нечетные числа из данного набора, а строкой ниже вывести их сумму.
            //Если требуемые числа в наборе отсутствуют, то вывести значение -1.

            try
            {
                string[] array = new string[100];
                int sum = 0;
                bool polozhnech = false;

                using (StreamReader sr = File.OpenText("Input3.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        array = input.Split(',');
                    }
                }

                int[] intArray = array.Select(s => int.Parse(s)).ToArray();

                using (StreamWriter writer = File.CreateText("Output3.txt"))
                {
                    if (array.Length >= 25)
                    {
                        for (int i = 0; i < array.Length; i++)
                        {
                            if (intArray[i] > 0 && intArray[i] % 2 != 0)
                            {
                                writer.Write(intArray[i] + " ");
                                sum += intArray[i];
                                polozhnech = true;
                            }
                        }
                        if (polozhnech == false)
                        {
                            writer.WriteLine("-1");
                        }
                    }
                    else
                    {
                        writer.WriteLine("Массив меньше 25 символов!");
                    }

                    if (polozhnech == true)
                    {
                        writer.WriteLine(" ");
                        writer.WriteLine("Сумма чисел = {0}", sum);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion

            #region Задание 4

                //Задание 4
                //Вводится строка.
                //Длина строки может быть разной.
                //Подсчитать количество содержащихся в этой строке чисел (от 0 до 9).
                //Вычислить и вывести сумму этих чисел.

            try
            {
                int sum1 = 0;
                int count = 0;
                Char[] chararray = null;

                using (StreamReader sr = File.OpenText("Input4.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        chararray = input.ToCharArray();
                    }
                    for (int i = 0; i < chararray.Length; i++)
                    {
                        if (Char.IsDigit(chararray[i]))
                        {
                            sum1 += Convert.ToInt32(chararray[i].ToString());
                            count++;
                        }
                    }
                }
                using (StreamWriter writer = File.CreateText("Output4.txt"))
                {
                    writer.WriteLine("число цифр = {0}", count);
                    writer.WriteLine("сумма цифр = {0}", sum1);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion
        }
    }
}

