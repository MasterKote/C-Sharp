﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr23_dll
{
    public class Zadanie1
    {
        public static bool koordchet(int x, int y)
        {
            if (x > 0 && y > 0)
            {
                return true;
            }
            else if(x < 0 && y < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    public class Zadanie2
    {
        public static double proizvedchis(int N)
        {
            double res = 1.0;
            for(int i = 1; i<=N ; i++)
            {
                res *= i;
            }
            return res;
        }
    }
    public class Zadanie5
    {
        public static int kolvodigits(int[] array, int N1)
        {
            int uniq = 0;
            for (int i = 0; i < N1; i++)
            {
                bool isuniq = true;
                for (int j = 0; j < i ; j++)
                {
                    if (array[i] == array[j])
                    {
                        isuniq = false;
                        break;
                    }
                }
                if (isuniq)
                {
                    uniq++;
                }
            }
            return uniq;
        }
    }
    public class Zadanie3
    {
        public static int countformin(int[] array, int N2)
        {
            int minIndex = 0;
            for (int i = 1; i < N2; i++)
            {
                if (array[i] < array[minIndex])
                {
                    minIndex = i;
                }
            }
            int count = minIndex;
            return count;
        }
    }
}
