﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using pr23_dll;

namespace pr23
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //zadanie 1
                //Даны ненулевые числа x, y. Проверить истинность высказывания: «Точка с координатами (x, y) лежит в первой или третьей координатной четверти».
                m1:
                Console.WriteLine("Введите ненулевое число X");
                int x = Convert.ToInt32(Console.ReadLine());
                if (x == 0)
                {
                    goto m1;
                }
                m2:
                Console.WriteLine("Введите ненулевое число Y");
                int y = Convert.ToInt32(Console.ReadLine());
                if (y == 0)
                {
                    goto m2;
                }

                Console.WriteLine(pr23_dll.Zadanie1.koordchet(x, y));
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                //zadanie 2
                //Дано целое число N (N > 0). Вывести произведение 1*2*3*...*N.
                //Чтобы избежать целочисленного переполнения, вычислять это произведение с помощью вещественной переменной и выводить его на экран как вещественное число.
                //Пример для числа 5 - 1*2*3*4*5=120.
                m3:
                Console.WriteLine("Введите целое число N (N > 0)");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N <= 0)
                {
                    goto m3;
                }

                Console.WriteLine("Произведение чисел:" + pr23_dll.Zadanie2.proizvedchis(N));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                Console.WriteLine("1 задание с массивом");
            //zadanie 5
            //Дан целочисленный массив, состоящий из N элементов (N > 0). Найти количество различных (не одинаковых) элементов в данном массиве.
            m4:
                Console.WriteLine("Введите количество элементов массива но не менее 30!");
                int N1 = Convert.ToInt32(Console.ReadLine());
                if (N1 < 30)
                {
                    goto m4;
                }
                int[] array = new int[N1];
                Random rand = new Random();
                for (int i = 0; i < array.Length; i++)
                {
                    array[i] = rand.Next(-50, 50);
                }

                Console.WriteLine("Количество различных элементов:" + pr23_dll.Zadanie5.kolvodigits(array, N1));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                //zadanie 3
                //Дан целочисленный массив, состоящий из N элементов (N > 0).
                //Найти и вывести количество элементов, расположенных перед первым минимальным элементом.
                Console.WriteLine("2 задание с массивом");
            m5:
                Console.WriteLine("Введите количество элементов массива но не менее 30!");
                int N2 = Convert.ToInt32(Console.ReadLine());
                if (N2 < 30)
                {
                    goto m5;
                }
                int[] array = new int[N2];
                Random rand = new Random();
                for (int i = 0; i < array.Length; i++)
                {
                    array[i] = rand.Next(-50, 50);
                }

                Console.WriteLine("Количество элементов перед минимальным:" + pr23_dll.Zadanie3.countformin(array, N2));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
