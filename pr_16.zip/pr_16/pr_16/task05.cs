﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task05
    {
        public int CountGlasn(string str)
        {
            char[] glasnie =
        {
            'a', 'e', 'i', 'o', 'u', 'y',
            'A', 'E', 'I', 'O', 'U', 'Y',

            'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я',
            'А', 'Е', 'Ё', 'И', 'О', 'У', 'Ы', 'Э', 'Ю', 'Я'
        };

            int count = 0;
            foreach (char c in str)
            {
                if (Array.IndexOf(glasnie, c) != -1)
                {
                    count++;
                }
            }
            return count;
        }
    }
}
