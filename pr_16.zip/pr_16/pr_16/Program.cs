﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using var25;

namespace pr_16
{
    internal class Program
    {
        static void Main(string[] args)
        {
        //Задание 1
        //Даны два целых положительных числа A и B (A < B).
        //Найти произведение всех нечётных чисел расположенных между этими числами A и B.
        M1:
            try
            {
                Console.WriteLine("Задание 1");
            M1_1:
                Console.WriteLine("Введите целое положительно число A");
                int A1 = Convert.ToInt32(Console.ReadLine());
                if (A1 <= 0)
                {
                    Console.WriteLine("Число A должно быть положительным");
                    goto M1_1;
                }
            M1_2:
                Console.WriteLine("Введите целое положительно число B");
                int B1 = Convert.ToInt32(Console.ReadLine());
                if (B1 <= 0)
                {
                    Console.WriteLine("Число B должно быть положительным");
                    goto M1_2;
                }
                if (A1 < B1)
                {
                    task01 task01 = new task01();
                    Console.WriteLine("произведение всех нечётных чисел расположенных между числами A и B = {0}", task01.Multiplication(A1, B1));
                }
                else
                {
                    Console.WriteLine("Число A должно быть меньше числа B");
                    goto M1_1;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }

            Console.WriteLine("");

        //Задание 2
        //Проверить истинность высказывания:
        //"Цифры данного целого положительного четырёхзначного числа образуют убывающую последовательность"
        M2:
            try
            {
                Console.WriteLine("Задание 2");
            M2_1:
                Console.WriteLine("Введите целое положительное четырёхзначное число");
                int chetznach = Convert.ToInt32(Console.ReadLine());
                if (chetznach >= 1000 && chetznach <= 9999)
                {
                    task02 task02 = new task02();
                    Console.WriteLine(task02.decreasseq(chetznach));
                }
                else
                {
                    Console.WriteLine("Число вне диапазона");
                    goto M2_1;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }

            Console.WriteLine("");

            //Задание 3
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Если в наборе имеются только положительные чётные числа,
            //то вывести True, в противном случае вывести False.
        M3:
            try
            {
                Console.WriteLine("Задание 3");

            Massive1:
                Console.WriteLine("Введите число элементов не менее 30");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N < 30)
                {
                    Console.WriteLine("В массиве должно быть не менее 30 элементов!");
                    goto Massive1;
                }
                int[] array = new int[N];
            Mmas:
                try
                {
                    Console.WriteLine("Выберите как хотите заполнимать массив, 1 - автоматически, 2 - ручной ввод");
                    int switchcs = Convert.ToInt32(Console.ReadLine());
                    switch (switchcs)
                    {
                        case 1:
                            Random rand = new Random();
                            for (int i = 0; i < array.Length; i++)
                            {
                                array[i] = rand.Next(-50, 50);
                            }
                            break;
                        case 2:
                            for (int i = 0; i < array.Length; i++)
                            {

                                Console.Write("Введите число {0}: ", i + 1);
                            Mmmas:
                                array[i] = 0;
                                try
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    goto Mmmas;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Введено неверное значение!");
                            goto Mmas;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    goto Mmas;
                }
                Console.WriteLine("Массив:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write(array[i] + " ");
                }
                Console.WriteLine("");
                task03 task03 = new task03();
                Console.WriteLine(task03.OnlyPositive(array));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }

            Console.WriteLine("");

        //Задание 4
        //Написать функцию double TriangleP(a) вещественного типа,
        //вычисляющую по стороне a равностороннего треугольника его периметр p = 3*a (параметр a является вещественным).
        //С помощью этой процедуры найти периметры трёх равносторонних треугольников с данными сторонами.
        M4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.WriteLine("Введите сторону a первого равностороннего треугольника");
                double a1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите сторону a второго равностороннего треугольника");
                double a2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите сторону a третьего равностороннего треугольника");
                double a3 = Convert.ToDouble(Console.ReadLine());
                task04 task04 = new task04();
                Console.WriteLine("Периметры первого, второго и третьего треугольника соответственно = {0}, {1}, {2}", task04.TriangleP(a1), task04.TriangleP(a2), task04.TriangleP(a3));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M4;
            }

            Console.WriteLine("");

        //Задание 5
        //Вводится строка, состоящая из слов, разделённых подчеркиваниями (одним или несколькими).
        //Длина строки может быть разной.
        //Подсчитать количество содержащихся в строке гласных букв.
        M5:
            try
            {
                Console.WriteLine("Задание 5");

                Console.WriteLine("Введите строку (слова разделены подчеркиваниями):");
                string str = Console.ReadLine();

                task05 task05 = new task05();
                Console.WriteLine($"Количество гласных букв в строке = "+ task05.CountGlasn(str));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M5;
            }
        }
    }
}
