﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task02
    {
        public string decreasseq(int chetznach)
        {
            int ch1 = chetznach / 1000;
            int ch2 = chetznach / 100 % 10;
            int ch3 = chetznach / 10 % 10;
            int ch4 = chetznach % 10;
            if (ch1 > ch2)
            {
                if (ch2 > ch3)
                {
                    if (ch3 > ch4)
                    {
                        return "Числа образуют убывающую последовательность";
                    }
                    else
                    {
                        return "Числа НЕ образуют убывающую последовательность";
                    }
                }
                else
                {
                    return "Числа НЕ образуют убывающую последовательность";
                }
            }
            else
            {
                return "Числа НЕ образуют убывающую последовательность";
            }
        }
    }
}
