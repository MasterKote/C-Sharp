﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task03
    {
        public bool OnlyPositive(int[] array)
        {
            bool onlyposchet = false;
            for (int i = 0; i <= array.Length; i++)
            {
                if(array[i] > 0 && array[i] %2 == 0)
                {
                    onlyposchet = true;
                }
                else
                {
                    onlyposchet = false;
                    break;
                }
            }
            return onlyposchet;
        }
    }
}
