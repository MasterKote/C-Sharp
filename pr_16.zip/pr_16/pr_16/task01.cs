﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var25
{
    internal class task01
    {
        public int Multiplication(int A, int B)
        {
            int proizved = 1;
            if (A %2 != 0)
            {
                for (int i = A+2; i < B; i+=2)
                {
                    proizved *= i;
                }
            }
            else if (A %2 == 0)
            {
                for (int i = A+1; i < B; i+=2)
                {
                    proizved *= i;
                }
            }
            return proizved;
        }
    }
}
