﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_10
{
    class Program
    {
        static string Zadanie1(int N1)
        {
            int Digit1 = N1 / 10000;
            int Digit2 = N1 / 1000 % 10;
            int Digit3 = N1 / 100 % 10;
            int Digit4 = N1 / 10 % 10;
            int Digit5 = N1 % 10;

            if (Digit1 != Digit2 && Digit1 != Digit3 && Digit1 != Digit4 && Digit1 != Digit5)
            {
                if (Digit2 != Digit3 && Digit2 != Digit4 && Digit2 != Digit5)
                {
                    if (Digit3 != Digit4 && Digit3 != Digit5)
                    {
                        if (Digit4 != Digit5)
                        {
                            return "Все цифры данного числа различны";
                        }
                        else
                        {
                            return "Не все цифры данного числа различны";
                        }
                    }
                    else
                    {
                        return "Не все цифры данного числа различны";
                    }
                }
                else
                {
                    return "Не все цифры данного числа различны";
                }
            }
            else
            {
                return "Не все цифры данного числа различны";
            }
        }
        static int Zadanie2(int N2)
        {
            int Digit1 = N2 / 1000;
            int Digit2 = N2 / 100 % 10;
            int Digit3 = N2 / 10 % 10;
            int Digit4 = N2 % 10;
            int proizved1 = Digit1 * Digit2;
            int proizved2 = Digit3 * Digit4;
            int raznica = Math.Abs(proizved1 - proizved2);
            return raznica;
        }
        static int Zadanie4(int A, int B, int C, int D)
        {
            int minznach = 0;
            if (A < B && A < C && A < D)
            {
                return minznach = A;
            }
            else if (B < A && B < C && B < D)
            {
                return minznach = B;
            }
            else if (C < A && C < B && C < D)
            {
                return minznach = C;
            }
            else if (D < A && D < B && D < C)
            {
                return minznach = D;
            }
            else
            {
                return minznach;
            }
        }
        static string Zadanie5(string N5)
        {
            string[] stroka = N5.Split('_');
            string shortWord = null;
            foreach (string word in stroka)
            {
                if (shortWord == null || word.Length < shortWord.Length)
                {
                    shortWord = word;
                }
            }
             return shortWord;
        }
        static void Main(string[] args)
        {
            M1:
            try
            {
                //Задание 1
                //Дано пятизначное целое положительное число N (N>0).
                //Проверить истинность высказывания: "Все цифры данного числа различны".
                Console.WriteLine("Задание 1");

                Console.WriteLine("Введите целое положительное пятизначное число");
                int N1 = Convert.ToInt32(Console.ReadLine());
                if (N1 >= 10000 && N1 <= 99999)
                {
                    string vivod1 = Zadanie1(N1);
                    Console.WriteLine(vivod1);
                }
                else
                {
                    Console.WriteLine("Число вне диапазона!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }
            Console.WriteLine("");

            M2:
            try
            {
                //Задание 2
                //Задано целое положительное четырехзначное число N (N > 0).
                //Найти разницу между произведениями первых двух и последних двух его цифр.
                Console.WriteLine("Задание 2");

                Console.WriteLine("Введите целое положительное четырёхзначное число");
                int N2 = Convert.ToInt32(Console.ReadLine());
                if (N2 >= 1000 && N2 <= 9999)
                {
                    int vivod2 = Zadanie2(N2);
                    Console.WriteLine("Разница между произведениями двух первых и двух последних цифр числа {0} = {1}", N2, vivod2);
                }
                else
                {
                    Console.WriteLine("Число вне диапазона!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M2;
            }

            Console.WriteLine("");

            M4:
            try
            {
                //Задание 4
                //Написать функцию int Min4(A, B, C, D) целого типа,
                //возвращающую одно минимальное значение из 4-х своих аргументов (параметры A, B, C и D - целые числа).
                Console.WriteLine("Задание 4");

                Console.WriteLine("Введите целые числа");
                Console.WriteLine("Введите число A");
                int A = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите число B");
                int B = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите число C");
                int C = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите число D");
                int D = Convert.ToInt32(Console.ReadLine());

                int vivod4 = Zadanie4(A, B, C, D);
                if (vivod4 == 0)
                {
                    Console.WriteLine("Нет единого минимального значения");
                }
                else
                {
                    Console.WriteLine("Минимальное значение = {0}", vivod4);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M4;
            }

            Console.WriteLine("");

            M5:
            try
            {
                //Задание 5
                //Вводится строка, состоящая из слов, разделенных подчеркиваниями.
                //Вывести строку, содержащую эти же слова, но разделенные одним символом '.' (точка).
                //Найти и вывести самое короткое слово из этой строки.
                Console.WriteLine("Задание 5");

                Console.WriteLine("Введите строку, содержащую слова, разделённые подчёркиваниями");
                string N5 = Console.ReadLine();
                string vivod5 = Zadanie5(N5);
                string[] stroka = N5.Split('_');
                string NewStroka = string.Join(".", stroka);
                Console.WriteLine("Строка разделённая точками = {0}", NewStroka);
                Console.WriteLine("Самое короткое слово = {0}", vivod5);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto M5;
            }
            Console.ReadKey();
        }
    }
}
