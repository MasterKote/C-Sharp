﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Word = Microsoft.Office.Interop.Word;

namespace pr21
{
    public partial class Form1 : Form
    {
        public static int Min3(int A,int B,int C)
        {
            return Math.Min(A, Math.Min(B, C));
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //Zadanie 1
                bool zadanie1bool = false;
                int zadanie1 = Convert.ToInt32(textBox1.Text);

                if (zadanie1 >= 100 && zadanie1 <= 999 && zadanie1 % 2 == 0)
                {
                    zadanie1bool = true;
                }
                else
                {
                    zadanie1bool = false;
                }

                //Zadanie 2
                int raznitca = 0;
                int zadanie2 = Convert.ToInt32(textBox2.Text);
                if (zadanie2 >= 1000 && zadanie2 <= 9999)
                {
                    int digit1 = (zadanie2 / 1000) % 10;
                    int digit2 = (zadanie2 / 100) % 10;
                    int digit3 = (zadanie2 / 10) % 10;
                    int digit4 = zadanie2 % 10;

                    int summofdigits = digit1 + digit2 + digit3 + digit4;
                    int proizvednechet = 1;
                    if (digit1 % 2 != 0)
                    {
                        proizvednechet *= digit1;
                    }
                    if (digit2 % 2 != 0)
                    {
                        proizvednechet *= digit2;
                    }
                    if (digit3 % 2 != 0)
                    {
                        proizvednechet *= digit3;
                    }
                    if (digit4 % 2 != 0)
                    {
                        proizvednechet *= digit4;
                    }

                    raznitca = Math.Abs(summofdigits - proizvednechet);
                }

                //Zadanie 3
                int[] array = null;
                int[] newarray = null;
                int N = Convert.ToInt32(textBox3.Text);
                if (N < 25)
                {
                    label5.Text = "В массиве должно быть не менее 25 элементов!";
                }
                else
                {
                    array = new int[N];
                    Random rand = new Random();
                    for (int i = 0; i < array.Length; i++)
                    {
                        array[i] = rand.Next(-50, 50);
                    }

                    int positivedigits = 0;
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] > 0)
                        {
                            positivedigits++;
                        }
                    }

                    newarray = new int[array.Length + positivedigits];
                    int index = 0;

                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] > 0)
                        {
                            newarray[index] = 0;
                            index++;
                            newarray[index] = array[i];
                            index++;
                        }
                        else
                        {
                            newarray[index] = array[i];
                            index++;
                        }
                    }
                }

                //Zadanie 4
                int summarray4 = 0;
                int proizved4 = 1;
                int[] array4 = null;
                int N4 = Convert.ToInt32(textBox4.Text);
                if (N4 < 25)
                {
                    label8.Text = "В массиве должно быть не менее 25 элементов!";
                }
                else
                {
                    array4 = new int[N];
                    Random rand = new Random();
                    for (int i = 0; i < array4.Length; i++)
                    {
                        array4[i] = rand.Next(-50, 50);
                    }

                    for (int i = 0; i < array4.Length; i++)
                    {
                        if (array4[i] % 2 == 0)
                        {
                            summarray4 += array4[i];
                            proizved4 *= array4[i];
                            ;
                        }
                    }
                }

                //Zadanie 5
                int A = Convert.ToInt32(zad5A.Text);
                int B = Convert.ToInt32(zad5B.Text);
                int C = Convert.ToInt32(zad5C.Text);

                int result5 = Min3( A, B, C);

                Word.Application wdApp = new Word.Application();
                Word.Document wdDoc = null;
                Object wdMiss = System.Reflection.Missing.Value;

                wdDoc = wdApp.Documents.Add(ref wdMiss, ref wdMiss, ref wdMiss, ref wdMiss);

                wdDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;

                wdDoc.PageSetup.TopMargin = wdApp.InchesToPoints(0.60f);
                wdDoc.PageSetup.BottomMargin = wdApp.InchesToPoints(0.60f);
                wdDoc.PageSetup.LeftMargin = wdApp.InchesToPoints(0.80f);
                wdDoc.PageSetup.RightMargin = wdApp.InchesToPoints(0.59f);

                wdApp.Visible = true;

                wdDoc.Content.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdDoc.Content.ParagraphFormat.SpaceAfter = 6.0f;

                Word.Paragraph para1;
                para1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para1.Range.Text = "МДК.01.01 Разработка программных модулей";
                para1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                para1.Range.Font.Size = Convert.ToInt32(18);
                para1.Range.Font.Bold = 1;
                para1.Range.InsertParagraphAfter();
                para1.CloseUp();

                Word.Paragraph para2;
                para2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para2.Range.Text = "ПР21 «Программное создание документов MS Word в языке С#»";
                para2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                para2.Range.Font.Size = Convert.ToInt32(16);
                para2.Range.Font.Bold = 0;
                para2.Range.InsertParagraphAfter();
                para2.CloseUp();

                Word.Paragraph para3;
                para3 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para3.Range.Text = "Выполнил Яруничев А.Р., студент группы ИС-23Б";
                para3.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                para3.Range.Font.Size = Convert.ToInt32(16);
                para3.Range.Font.Bold = 0;
                para3.Range.InsertParagraphAfter();
                para3.CloseUp();

                Word.Paragraph para4;
                para4 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para4.Range.Text = $"Задание 1\vНачальное число: {zadanie1}\vРезультат: {zadanie1bool}";
                para4.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                para4.Range.Font.Size = Convert.ToInt32(16);
                para4.Range.Font.Bold = 0;
                para4.Range.InsertParagraphAfter();
                para4.CloseUp();

                Word.Paragraph para5;
                para5 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para5.Range.Text = $"Задание 2\vНачальное число: {zadanie2}\vРезультат: {raznitca}";
                para5.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                para5.Range.Font.Size = Convert.ToInt32(16);
                para5.Range.Font.Bold = 0;
                para5.Range.InsertParagraphAfter();
                para5.CloseUp();

                Word.Paragraph para6;
                para6 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para6.Range.Text = $"Задание 3\vНачальный массив: {string.Join(", ", array)}\vРезультат: {string.Join(", ", newarray)}";
                para6.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                para6.Range.Font.Size = Convert.ToInt32(16);
                para6.Range.Font.Bold = 0;
                para6.Range.InsertParagraphAfter();
                para6.CloseUp();

                Word.Paragraph para7;
                para7 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para7.Range.Text = $"Задание 4\vНачальный массив: {string.Join(", ", array4)}\vРезультат сумма: {summarray4}\vРезультат произведение: {proizved4}";
                para7.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                para7.Range.Font.Size = Convert.ToInt32(16);
                para7.Range.Font.Bold = 0;
                para7.Range.InsertParagraphAfter();
                para7.CloseUp();

                Word.Paragraph para8;
                para8 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                para8.Range.Text = $"Задание 5\vНачальные числа: {A},{B},{C}\vРезультат: {result5}";
                para8.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                para8.Range.Font.Size = Convert.ToInt32(16);
                para8.Range.Font.Bold = 0;
                para8.Range.InsertParagraphAfter();
                para8.CloseUp();

                try
                {
                    object filename = @"pr21" + ".doc";

                    wdDoc.SaveAs(ref filename);

                    wdDoc.Close(ref wdMiss, ref wdMiss, ref wdMiss);
                    wdDoc = null;

                    wdApp.Quit(ref wdMiss, ref wdMiss, ref wdMiss);
                    wdDoc = null;
                }
                catch (Exception y)
                {
                    Console.WriteLine("Ошибка сохранения документа", y.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
