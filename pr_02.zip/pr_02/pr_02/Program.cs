﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace pr_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ZADANIE 1
            try
            {
                int a = 0;
                Console.WriteLine("Введите целое положительное чётное трёхзначное число");
                a = Convert.ToInt32(Console.ReadLine());


                //else Console.WriteLine("Значение {0} не соответствует задаче", a);

                //else Console.WriteLine("Значение {0} не соответствует задаче", a);
                if (a >= 100 & a <= 999)
                {
                    if (a % 2 == 0)
                    {
                        Console.WriteLine("Значение {0} соответствует задаче", a);
                    }
                    else
                    {
                        Console.WriteLine("Значение {0} не соответствует задаче", a);
                    }
                }
                else
                {
                    Console.WriteLine("Значение {0} не соответствует задаче", a);
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (OverflowException e1)
            {
                    Console.WriteLine(e1.Message);
            }

            Console.WriteLine();

            //ZADANIE 2
            try
            {
                Console.WriteLine("Введите шесть целых ненулевых положительных чисел");

                int chislo1 = 0;
                Console.WriteLine("Введите первое число");
                chislo1 = Convert.ToInt32(Console.ReadLine());

                int chislo2 = 0;
                Console.WriteLine("Введите второе число");
                chislo2 = Convert.ToInt32(Console.ReadLine());

                int chislo3 = 0;
                Console.WriteLine("Введите третье число");
                chislo3 = Convert.ToInt32(Console.ReadLine());

                int chislo4 = 0;
                Console.WriteLine("Введите четвёртое число");
                chislo4 = Convert.ToInt32(Console.ReadLine());

                int chislo5 = 0;
                Console.WriteLine("Введите пятое число");
                chislo5 = Convert.ToInt32(Console.ReadLine());

                int chislo6 = 0;
                Console.WriteLine("Введите шестое число");
                chislo6 = Convert.ToInt32(Console.ReadLine());

                int min1 = Math.Min(chislo1, chislo2);
                int min2 = Math.Min(chislo3, chislo4);
                int min3 = Math.Min(chislo5, chislo6);

                int Summm = min1 + min2 + min3;
                Console.WriteLine("Сумма трёх наименьших чисел = {0}", Summm);
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (OverflowException e1)
            {
                Console.WriteLine(e1.Message);
            }

            Console.WriteLine();

            //ZADANIE3
            try
            {
                int schet = 0;
                Console.WriteLine("Проверка есть ли среди трех данных целых положительных чисел хотя бы одна пара совпадающих");

                int chislo1 = 0;
                Console.WriteLine("Введите первое число");
                chislo1 = Convert.ToInt32(Console.ReadLine());

                int chislo2 = 0;
                Console.WriteLine("Введите первое число");
                chislo2 = Convert.ToInt32(Console.ReadLine());

                int chislo3 = 0;
                Console.WriteLine("Введите первое число");
                chislo3 = Convert.ToInt32(Console.ReadLine());

                if (chislo1 == chislo2)
                {
                    Console.WriteLine("Число {0} и число {1} равны", chislo1, chislo2);
                    schet += 1;
                }
                if (chislo1 == chislo3)
                {
                    Console.WriteLine("Число {0} и число {1} равны", chislo1, chislo3);
                    schet += 1;
                }
                if (chislo2 == chislo3)
                {
                    Console.WriteLine("Число {0} и число {1} равны", chislo2, chislo3);
                    schet += 1;
                }
                Console.WriteLine("Количество пар удовлетворяющих условию = {0}", schet);
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (OverflowException e1)
            {
                Console.WriteLine(e1.Message);
            }

            Console.WriteLine() ;

            //ZADANIE 4
            try
            {
                int a1_1 = 0;
                int a2_1 = 0;
                int a3_1 = 0;
                int a4_1 = 0;
                int a1 = 0;
                int a2 = 0;
                int a3 = 0;
                int a4 = 0;
                int chetzn = 0;
                Console.WriteLine("Введите целое положительное четырехзначное число");
                chetzn = Convert.ToInt32(Console.ReadLine());

                if (chetzn >= 1000 & chetzn <= 9999)
                {
                    a1 = (chetzn / 1000);
                    a2 = (chetzn / 100 % 10);
                    a3 = (chetzn / 10 % 10);
                    a4 = (chetzn % 10);
                    int SUMCHISL = a1 + a2 + a3 + a4;
                    int raznitsasumm = chetzn - SUMCHISL;
                    Console.WriteLine("Разница между числом и суммой цифр = {0}", raznitsasumm);

                    if (a1 % 2 == 0)
                    {
                        a1_1 = a1;
                    }
                    else
                    {
                        a1_1 = 1;
                    }
                    if (a2 % 2 == 0)
                    {
                        a2_1 = a2;
                    }
                    else
                    {
                        a2_1 = 1;
                    }
                    if (a3 % 2 == 0)
                    {
                        a3_1 = a3;
                    }
                    else
                    {
                        a3_1 = 1;
                    }
                    if (a4 % 2 == 0)
                    {
                        a4_1 = a4;
                    }
                    else
                    {
                        a4_1 = 1;
                    }
                    int proizved = a1_1 * a2_1 * a3_1 * a4_1;
                    int raznproizved = chetzn - proizved;
                    Console.WriteLine("Разница между числом и произведением цифр = {0}", raznproizved);
                }
                else
                {
                    Console.WriteLine("Введено неверное число!!!");
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (OverflowException e1)
            {
                Console.WriteLine(e1.Message);
            }

            Console.WriteLine();

            //ZADANIE 5
            try
            {
                int year = 0;
                Console.WriteLine("Введите год в диапазоне от 1984 до 2025(включительно)");
                year = Convert.ToInt32(Console.ReadLine());

                if (year >= 1984 & year <= 2025)
                {
                    int cycleyear = (year - 1984) % 60;

                    string color;
                    switch (cycleyear/12)
                    {
                        case 0: color = "зелёный";
                            break;
                        case 1: color = "красный";
                            break;
                        case 2: color = "жёлтый";
                            break;
                        case 3: color = "белый";
                            break;
                        case 4: color = "чёрный";
                            break;
                        default: color = "";
                            break;
                    }
                    string animal;
                    switch (cycleyear%12)
                    {
                        case 0: animal = "крыса";
                            break;
                        case 1: animal = "корова";
                            break;
                        case 2: animal = "тигр";
                            break;
                        case 3: animal = "заяц";
                            break;
                        case 4: animal = "дракон";
                            break;
                        case 5: animal = "змея";
                            break;
                        case 6: animal = "лошадь";
                            break;
                        case 7: animal = "овца";
                            break;
                        case 8: animal = "обезьяна";
                            break;
                        case 9: animal = "курица";
                            break;
                        case 10: animal = "собака";
                            break;
                        case 11: animal = "свинья";
                            break;
                        default: animal = "";
                            break;
                    }
                    Console.WriteLine("год {0} - это год <{1} {2}>", year, color, animal);
                }
                else
                {
                    Console.WriteLine("Введён год выходящий за диапазон!!!");
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (OverflowException e1)
            {
                Console.WriteLine(e1.Message);
            }
            Console.WriteLine("Для выхода нажмите любую клавишу");
            Console.ReadKey();
        }
    }
}
