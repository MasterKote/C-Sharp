﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double A1 = Convert.ToDouble(textBox1.Text);
                double B1 = Convert.ToDouble(textBox2.Text);
                double C1 = Convert.ToDouble(textBox3.Text);

                double discriminant = Math.Pow(B1, 2) - 4 * A1 * C1;
                if (discriminant < 0)
                {
                    label5.Text = "Выражение истинно";
                }
                else
                {
                    label5.Text = "Выражение ложно";
                }
            }
            catch (Exception ex)
            {
                label7.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int zad2 = Convert.ToInt32(textBox4.Text);

                int digit1 = zad2 / 100;
                int digit2 = (zad2 / 10) % 10;
                int digit3 = zad2 % 10;

                int newNumber = digit2 + digit1 * 10 + digit3 * 100;
                label11.Text = newNumber.ToString();
            }
            catch (Exception ex)
            {
                label12.Text = ex.Message;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int A3 = Convert.ToInt32(textBox5.Text);
                int B3 = Convert.ToInt32(textBox6.Text);

                if (A3 > B3)
                {
                    label17.Text = "0";
                }
                else
                {
                    label17.Text = SumRangeOdd(A3, B3).ToString();
                }
            }
            catch (Exception ex)
            {
                label18.Text = ex.Message;
            }
        }

        public int SumRangeOdd(int A3, int B3)
        {
            int summalldigit = 0;
            for (int i = A3; i <= B3; i++)
            {
                if (i % 2 != 0)
                {
                    summalldigit += i;
                }
            }
            return summalldigit;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                label21.Text = "";
                label22.Text = "";
                int N = Convert.ToInt32(textBox7.Text);
                if (N < 20)
                {
                    label21.Text = "В массиве должно быть не менее 20 элементов!";
                }
                else
                {
                    int[] array = new int[N];
                    Random rand = new Random();
                    for (int i = 0; i < array.Length; i++)
                    {
                        array[i] = rand.Next(-50, 50);
                    }

                    for (int i = 0; i < array.Length; i++)
                    {
                        label21.Text += (array[i] + " ");
                    }

                    int maxindex = Array.IndexOf(array, array.Max());
                    int minindex = Array.IndexOf(array, array.Min());

                    int temp = array[minindex];
                    array[minindex] = array[maxindex];
                    array[maxindex] = temp;

                    for (int i = 0; i < array.Length; i++)
                    {
                        label22.Text += (array[i] + " ");
                    }
                }
            }
            catch (Exception ex)
            {
                label21.Text = ex.Message;
            }
        }
    }
}
