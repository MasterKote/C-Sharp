﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace pr_08
{
    internal class Program
    {
        static int Max3Of5Sum(int A,int B,int C,int D,int E)
        {
            int[] intMax3o5s = {A,B,C,D,E};

            Array.Sort(intMax3o5s);
            Array.Reverse(intMax3o5s);

            return intMax3o5s[0] + intMax3o5s[1] + intMax3o5s[2];
        }
        static int MinDigit(string K1)
        {
            int MinDigit2 = 9;
            Char[] charmin = K1.ToCharArray();
            for (int i = 0; i < charmin.Length; i++)
            {
                int MinDigitchar = Convert.ToInt32(charmin[i].ToString());
                if (MinDigitchar < MinDigit2)
                {
                    MinDigit2 = MinDigitchar;
                }
            }
            return MinDigit2;
        }
        static string Zadanie1(int DigitZad1)
        {
            int Digit1 = DigitZad1 / 1000;
            int Digit2 = DigitZad1 / 100 % 10;
            int Digit3 = DigitZad1 / 10 % 10;
            int Digit4 = DigitZad1 % 10;
            if (Digit1 > Digit2)
            {
                if (Digit2 > Digit3)
                {
                    if (Digit3 > Digit4)
                    {
                        return "Высказывание истинно";
                    }
                    else
                    {
                        return "Высказывание ложно";
                    }
                }
                else
                {
                    return "Высказывание ложно";
                }
            }
            else
            {
                return "Высказывание ложно";
            }
        }
        
        static int[] Zadanie2(int[] array)
        {
            int[] newarray = array;
            int mindigit = array.Min();
            int maxdigit = array.Max();
            int minindex = Array.IndexOf(array, mindigit);
            int maxindex = Array.IndexOf(array, maxdigit);
            int temp = newarray[minindex];
            newarray[minindex] = newarray[maxindex];
            newarray[maxindex] = temp;
            return newarray;
        }

        static string[] Zadanie3(string word)
        {
            string[] podcherk = word.Split('_');
            List<string> letterxxx = new List<string>();
            foreach (var word1 in podcherk)
            {
                int countx = 0;
                for (int i = 0; i < word1.Length; i++)
                {
                    if (word1[i] == 'x' || word1[i] == 'X' || word1[i] == 'х' || word1[i] == 'Х')
                    {
                        countx++;
                    }
                }
                if (countx == 3)
                {
                    letterxxx.Add(word1);
                }
            }
            return letterxxx.ToArray();
        }
        static void Main(string[] args)
        {
        M_main:
            try
            {
                Console.WriteLine("Выберите задание 1-5, чтобы выйти 6:");
                int num_zadanie = Convert.ToInt32(Console.ReadLine());

                switch (num_zadanie)
                {
                    case 1:
                    case1:
                        try
                        {
                            //Проверить истинность высказывания:
                            //"Цифры данного целого положительного четырехзначного числа образуют убывающую последовательность".
                            Console.WriteLine("Задание 1");
                        M1:
                            Console.WriteLine("Введите целое положительное четырёхзначное число:");
                            int DigitZad1 = Convert.ToInt32(Console.ReadLine());
                            if (DigitZad1 >= 1000 && DigitZad1 <= 9999)
                            {
                                string result = Zadanie1(DigitZad1);
                                Console.WriteLine(result);
                                goto M_main;
                            }
                            else
                            {
                                Console.WriteLine("Число вне диапазона!");
                                goto M1;
                            }
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case1;
                        }
                        catch (OverflowException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case1;
                        }
                    case 2:
                    case2:
                        try
                        {
                            //Дан целочисленный массив, состоящий из N элементов(N > 0).
                            //Поменять местами минимальный и максимальный элемент в массиве.
                            //Вывести вначале исходный массив, а строкой ниже полученный массив после замены.
                            Console.WriteLine("Задание 2");
                        M_massive:
                            int N = 0;

                            Console.WriteLine("Введите число элементов массива, но не меньше 25!");
                            N = Convert.ToInt32(Console.ReadLine());
                            if (N < 25)
                            {
                                Console.WriteLine("Число элементов массива меньше 25!");
                                goto M_massive;
                            }
                            int[] array = new int[N];
                        M2:
                            try
                            {
                                Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                                int Vvod = Convert.ToInt32(Console.ReadLine());
                                switch (Vvod)
                                {
                                    case 1:
                                        Random rand = new Random();
                                        for (int i = 0; i < array.Length; i++)
                                        {
                                            array[i] = rand.Next(-50, 50);
                                        }
                                        break;
                                    case 2:
                                        for (int i = 0; i < array.Length; i++)
                                        {

                                            Console.Write("Введите число {0}: ", i + 1);
                                        M2_1:
                                            array[i] = 0;
                                            try
                                            {
                                                array[i] = Convert.ToInt32(Console.ReadLine());
                                            }
                                            catch (OverflowException e)
                                            {
                                                Console.WriteLine(e.Message);
                                                goto M2_1;
                                            }
                                            catch (FormatException e)
                                            {
                                                Console.WriteLine(e.Message);
                                                goto M2_1;
                                            }
                                        }
                                        break;
                                    default:
                                        Console.WriteLine("Введено неверное значение!");
                                        goto M2;
                                }
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine(e.Message);
                                goto M2;
                            }
                            catch (OverflowException e)
                            {
                                Console.WriteLine(e.Message);
                                goto M2;
                            }
                            Console.WriteLine("Массив:");
                            for (int i = 0; i < array.Length; i++)
                            {
                                Console.Write(array[i] + " ");
                            }
                            int[] newarray = Zadanie2(array);
                            Console.WriteLine("");
                            Console.WriteLine("Новый массив:");
                            for (int i = 0; i < newarray.Length; i++)
                            {
                                Console.Write(newarray[i] + " ");
                            }
                            Console.WriteLine("");
                            Console.WriteLine("");
                            goto M_main;
                        }
                        catch (OverflowException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case2;
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case2;
                        }
                    case 3:
                        case3:
                        try
                        {
                            //Вводится строка, состоящая из слов, разделенных подчеркиваниями(одним или несколькими).
                            //Длина строки может быть разной.
                            //Определить и вывести на экран слово/ слова, которые содержат ровно три буквы 'x'.
                            Console.WriteLine("Задание 3");
                            Console.WriteLine("Введите символы разделённые подчёркиваниями");
                            string word = Console.ReadLine();
                            string[] letterwithx = Zadanie3(word);
                            if (letterwithx.Length > 0)
                            {
                                Console.WriteLine("Слова, содержащие ровно три буквы 'x':");
                                foreach (var word1 in letterwithx)
                                {
                                    Console.WriteLine(word1);
                                }
                                Console.WriteLine("");
                                goto M_main;
                            }
                            else
                            {
                                Console.WriteLine("Нет слов, содержащих ровно три буквы 'x'.");
                                Console.WriteLine("");
                                goto M_main;
                            }
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case3;
                        }
                        catch (OverflowException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case3;
                        }
                    case 4:
                        case4:
                        try
                        {
                            //Написать функцию int MinDigit(K) целого типа,
                            //возвращающую минимальную цифру в целом положительном числе K.
                            Console.WriteLine("Задание 4");
                            case4_1:
                            Console.WriteLine("Введите целое положительное число K:");
                            int K = Convert.ToInt32(Console.ReadLine());
                            if (K > 0)
                            {
                                string K1 = K.ToString();
                                int result4 = MinDigit(K1);
                                Console.WriteLine("Минимальная цифра числа K = {0}", result4);
                                goto M_main;
                            }
                            else
                            {
                                Console.WriteLine("Число должно быть положительным!");
                                goto case4_1;
                            }
                        }
                        catch (OverflowException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case4;
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case4;
                        }
                    case 5:
                        case5:
                        try
                        {
                            //Написать функцию int Max3Of5Sum(A, B, C, D, E) целого типа,
                            //возвращающую сумму трех самых максимальных значений из 5-ти своих аргументов (параметры A, B, C, D и E - целые числа).
                            Console.WriteLine("Задание 5");
                            Console.WriteLine("Введите число A");
                            int A = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Введите число B");
                            int B = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Введите число C");
                            int C = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Введите число D");
                            int D = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Введите число E");
                            int E = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Сумма 3-ёх максимальных значений = {0}", Max3Of5Sum(A,B,C,D,E));
                            goto M_main;
                        }
                        catch (OverflowException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case5;
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("");
                            goto case5;
                        }
                    case 6:
                        break;
                    default:
                        Console.WriteLine("Введено неверное значение!");
                        Console.WriteLine("");
                        goto M_main;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("");
                goto M_main;
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("");
                goto M_main;
            }
        }
    }
}
