﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using dllAPP;

namespace PR32
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Проверить истинность высказывания:
            //"Сумма двух первых цифр данного целого положительного
            //четырехзначного числа равна сумме двух его последних цифр".
            try
            {
                Console.WriteLine("Zadanie 1");
            task1_1:
                Console.WriteLine("Введите целое положительное 4-х значное число");
                int number_task1 = Convert.ToInt32(Console.ReadLine());
                if (number_task1 >= 1000 && number_task1 <= 9999)
                {
                    task1 task1 = new task1();
                    Console.WriteLine(task1.Task1_func(number_task1));
                }
                else
                {
                    Console.WriteLine("Число вне диапазона!");
                    goto task1_1;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();

            //Ввести пять различных ненулевых целых чисел.
            //Найти произведение трех наибольших чисел.
            try
            {
                Console.WriteLine("Zadanie 2");
                Console.WriteLine("Введите пять различных ненулевых чисел");
                int[] intarray = new int[5];
                for (int i = 0; i < 5; i++)
                {
                task2_1:
                    Console.WriteLine($"Введите {i + 1}-ое число");
                    intarray[i] = Convert.ToInt32(Console.ReadLine());
                    if (intarray[i] == 0)
                    {
                        Console.WriteLine("Число должно быть ненулевое!");
                        goto task2_1;
                    }
                }

                task2 task2 = new task2();
                Console.WriteLine(task2.task2_func(intarray));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();

            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Сложить со всеми четными числами максимальное нечетное число из этого массива.
            //Вывести новый полученный массив.
            try
            {
                Console.WriteLine("Zadanie 3");
            task3_1:
                Console.WriteLine("Введите кол-во элементов массива (N > 25)");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N < 25)
                {
                    Console.WriteLine("Кол-во элементов должно быть больше 25!");
                    goto task3_1;
                }

                int[] intarray2 = new int[N];
                Random rand = new Random();

                for (int i = 0; i < N; i++)
                {
                    intarray2[i] = rand.Next(-50, 50);
                }

                Console.WriteLine("Массив");
                for (int i = 0;i < N; i++)
                {
                    Console.Write(intarray2[i] + " ");
                }
                Console.WriteLine();

                task3 task3 = new task3();
                intarray2 = task3.task3_func(intarray2);

                Console.WriteLine("Изменённый массив");
                for (int i = 0; i < N; i++)
                {
                    Console.Write(intarray2[i] + " ");
                }
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();

            //Написать функцию bool Even(K) логического типа,
            //возвращающую True, если целый параметр K является четным,
            //и False в противном случае.
            //С ее помощью найти количество четных чисел в наборе из 10 целых положительных чисел.
            try
            {
                Console.WriteLine("Zadanie 4");
                Console.WriteLine("Введите 10 целых положительных чисел");
                int[] intarray3 = new int[10];
                for (int i = 0; i < 10; i++)
                {
                task4_1:
                    Console.WriteLine($"Введите {i + 1}-ое число");
                    intarray3[i] = Convert.ToInt32(Console.ReadLine());
                    if (intarray3[i] == 0)
                    {
                        Console.WriteLine("Число должно быть положительное!");
                        goto task4_1;
                    }
                }

                task4 task4 = new task4();
                Console.WriteLine($"Количество чётных чисел: {task4.task4_func(intarray3)}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
