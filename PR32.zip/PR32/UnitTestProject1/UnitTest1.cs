﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using dllAPP;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTestTask1
    {
        [TestMethod]
        public void TestMethod1()
        {
            bool Expected = true;

            bool Actual = task1.Task1_func(1111);

            Assert.AreEqual(Expected, Actual);
        }

        [TestMethod]
        public void TestMethod2()
        {
            bool Expected2 = false;

            bool Actual2 = task1.Task1_func(1232);

            Assert.AreEqual(Expected2, Actual2);
        }

        [TestMethod]
        public void TestMethod3()
        {
            bool Expected3 = true;

            bool Actual3 = task1.Task1_func(4554);

            Assert.AreEqual(Expected3, Actual3);
        }
    }

    [TestClass]
    public class UnitTestTask2
    {
        [TestMethod]
        public void TestMethod1()
        {
            int Expected = 60;

            int[] Actualarray = { 1, 2, 3, 4, 5 };

            int Actual = task2.task2_func(Actualarray);

            Assert.AreEqual(Expected, Actual);
        }

        [TestMethod]
        public void TestMethod2()
        {
            int Expected2 = 60;

            int[] Actualarray2 = { 5,4,3,2,1 };

            int Actual2 = task2.task2_func(Actualarray2);

            Assert.AreEqual(Expected2, Actual2);
        }

        [TestMethod]
        public void TestMethod3()
        {
            int Expected3 = 1204;

            int[] Actualarray3 = { -43, 7, 43, 2, 4 };

            int Actual3 = task2.task2_func(Actualarray3);

            Assert.AreEqual(Expected3, Actual3);
        }
    }

    [TestClass]
    public class UnitTestTask3
    {
        [TestMethod]
        public void TestMethod1()
        {
            int[] Expected = { 1, 2, 3, 4, 11 };

            int[] Actualarray = { 1, 2, 3, 4, 5 };

            int[] Actual = task3.task3_func(Actualarray);

            CollectionAssert.AreEqual(Expected, Actual);
        }

        [TestMethod]
        public void TestMethod2()
        {
            int[] Expected2 = { 3, 5, 7, 13, 4 };

            int[] Actualarray2 = { 3, 5, 7, 9, 4 };

            int[] Actual2 = task3.task3_func(Actualarray2);

            CollectionAssert.AreEqual(Expected2, Actual2);
        }

        [TestMethod]
        public void TestMethod3()
        {
            int[] Expected3 = { 47, 54, -32, 4, 64 };

            int[] Actualarray3 = { -43, 54, -32, 4, 64 };

            int[] Actual3 = task3.task3_func(Actualarray3);

            CollectionAssert.AreEqual(Expected3, Actual3);
        }
    }

    [TestClass]
    public class UnitTestTask4
    {
        [TestMethod]
        public void TestMethod1()
        {
            int Expected = 2;

            int[] Actualarray = { 1, 2, 3, 4, 5 };

            int Actual = task4.task4_func(Actualarray);

            Assert.AreEqual(Expected, Actual);
        }

        [TestMethod]
        public void TestMethod2()
        {
            int Expected = 0;

            int[] Actualarray = { 1, 3, 5, 7, 9 };

            int Actual = task4.task4_func(Actualarray);

            Assert.AreEqual(Expected, Actual);
        }

        [TestMethod]
        public void TestMethod3()
        {
            int Expected = 5;

            int[] Actualarray = { 2, 4, 6, 8, 10 };

            int Actual = task4.task4_func(Actualarray);

            Assert.AreEqual(Expected, Actual);
        }
    }
}
