﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllAPP
{
    public class task1
    {
        /// <summary>
        /// Проверяет, равняется ли сумма первых двух чисел двум последним числам
        /// </summary>
        /// <param name="number_task1">Вводим 4х значное число</param>
        /// <returns>Возвращаем true or false в зависимости от результата</returns>
        public static bool Task1_func(int number_task1)
        {
            int sum1 = 0;
            int sum2 = 0;
            int digit1 = (number_task1 / 1000) % 10;
            int digit2 = (number_task1 / 100) % 10;
            int digit3 = (number_task1 / 10) % 10;
            int digit4 = number_task1 % 10;

            sum1 = digit1 + digit2;
            sum2 = digit3 + digit4;

            if (sum1 == sum2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
