﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllAPP
{
    public class task3
    {
        /// <summary>
        /// Складываем все чётные числа с макс. нечётным числом
        /// </summary>
        /// <param name="intarray2">Вводим массив с числами</param>
        /// <returns>Возвращаем полученный массив</returns>
        public static int[] task3_func(int[] intarray2)
        {
            int sumofpoloz = 0;
            int indexmaxnechet = 0;
            int maxnechet = -51;

            for (int i = 0; i < intarray2.Length; i++)
            {
                if(intarray2[i] %2 != 0)
                {
                    if (intarray2[i] > maxnechet)
                    {
                        maxnechet = intarray2[i];
                    }
                }

                if(intarray2[i] %2 == 0)
                {
                    sumofpoloz += intarray2[i];
                }
            }
            indexmaxnechet = Array.IndexOf(intarray2, maxnechet);

            intarray2[indexmaxnechet] += sumofpoloz;
            return intarray2;
        }
    }
}
