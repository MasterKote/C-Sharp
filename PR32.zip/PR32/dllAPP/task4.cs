﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllAPP
{
    public class task4
    {
        /// <summary>
        /// Находим кол-во чётных чисел среди 10, вызывая функцию Even
        /// </summary>
        /// <param name="intarray3">Вводим массив чисел</param>
        /// <returns>Возвращаем кол-во чётных чисел</returns>
        public static int task4_func(int[] intarray3)
        {
            int kolvochetdigits = 0;
            for (int i = 0; i < intarray3.Length; i++)
            {
                bool istrue = task4.Even(intarray3[i]);
                if (istrue == true)
                {
                    kolvochetdigits++;
                }
            }
            return kolvochetdigits;
        }
        /// <summary>
        /// Проверяем, является ли число чётным
        /// </summary>
        /// <param name="K">Вводим одно число из массив</param>
        /// <returns>Возвращаем результат</returns>
        static bool Even(int K)
        {
            if (K %2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
