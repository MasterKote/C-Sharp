﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllAPP
{
    public class task2
    {
        /// <summary>
        /// Среди 5-ти чисел найти 3 максимальных и найти их произведением
        /// </summary>
        /// <param name="intarray">Вводим массив с числами</param>
        /// <returns>Возвращаем произведение 3-ёх макс. чисел</returns>
        public static int task2_func(int[] intarray)
        {
            int proiz = 1;

            Array.Sort(intarray);
            Array.Reverse(intarray);
            
            proiz = intarray[0] * intarray[1] * intarray[2];

            return proiz;
        }
    }
}
