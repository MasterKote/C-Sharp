﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace pr_09
{
    internal class Program
    {
        static double TriangleP(double a)
        {
            return a*3;
        }
        static int RootCount(double A, double B, double C)
        {
            double discriminant = Math.Pow(B, 2) - (4 * A * C);
            if (discriminant > 0)
            {
                return 1;
            }
            else if (discriminant == 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        static void Main(string[] args)
        {
            #region Задание 1
            //Задание 1
            //Дано четырехзначное целое ненулевое положительное число N (N>0).
            //Проверить истинность высказывания: "Все цифры данного числа одинаковые".

            try
            {
                int A = 0;
                using (StreamReader sr = File.OpenText("Input1.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        A = Convert.ToInt32((string)input);
                    }
                }
                using (StreamWriter writer = File.CreateText("Output1.txt"))
                {
                    if (A >= 1000 && A <= 9999)
                    {
                        int num1 = A / 1000;
                        int num2 = A / 100 % 10;
                        int num3 = A / 10 % 10;
                        int num4 = A % 10;
                        if (num1 == num2 && num1 == num3 && num1 == num4)
                        {
                            writer.WriteLine("Все цифры данного числа одинаковые");
                        }
                        else
                        {
                            writer.WriteLine("Не все цифры данного числа одинаковы или неодинаковы совсем");
                        }
                    }
                    else
                    {
                        writer.WriteLine("Число вне диапазона!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion

            #region Задание 2
            //Задание 2
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Переставить в обратном порядке элементы массива,
            //расположенные между его минимальным и максимальным элементами,
            //включая минимальный и максимальный элементы.

            try
            {
                string[] array = new string[100];

                using (StreamReader sr = File.OpenText("Input2.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        array = input.Split(',');
                    }
                }
                int[] intArray = array.Select(s => int.Parse(s)).ToArray();
                using (StreamWriter writer = File.CreateText("Output2.txt"))
                {
                    if (array.Length >= 25)
                    {
                        int minindex = Array.IndexOf(intArray, intArray.Min());
                        int maxindex = Array.IndexOf(intArray, intArray.Max());
                            while (minindex < maxindex)
                            {
                                // Меняем местами элементы
                                int temp = intArray[minindex];
                                intArray[minindex] = intArray[maxindex];
                                intArray[maxindex] = temp;

                                minindex++;
                                maxindex--;
                            }
                            writer.WriteLine(string.Join(",", intArray));
                    }
                    else
                    {
                        writer.WriteLine("Массив меньше 25 символов!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion

            #region Задание 4
            //Задание 4
            //Написать функцию double TriangleP(a) вещественного типа,
            //вычисляющую по стороне a равностороннего треугольника его периметр P = 3·a(параметр a является вещественным).
            //С помощью этой процедуры найти периметры трех равносторонних треугольников с данными сторонами.
            try
            {
                string[] array1 = new string[3];
                using (StreamReader sr = File.OpenText("Input4.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        array1 = input.Split('_');
                    }
                }
                double[] doubleArray = array1.Select(s => double.Parse(s)).ToArray();
                using (StreamWriter writer = File.CreateText("Output4.txt"))
                {
                    double a1 = doubleArray[0];
                    double a2 = doubleArray[1];
                    double a3 = doubleArray[2];
                    double P1 = TriangleP(a1);
                    double P2 = TriangleP(a2);
                    double P3 = TriangleP(a3);
                    writer.WriteLine("Периметр равностороннего треугольника (со стороной = {0}) = {1}", a1, P1);
                    writer.WriteLine("Периметр равностороннего треугольника (со стороной = {0}) = {1}", a2, P2);
                    writer.WriteLine("Периметр равностороннего треугольника (со стороной = {0}) = {1}", a3, P3);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значение в файле!");
            }
            #endregion

            #region Задание 5
            //Задание 5
            //Написать функцию int RootCount(A, B, C) целого типа,
            //определяющую количество корней квадратного уравнения A*x2 + B*x + C = 0 (A, B, C — вещественные параметры, A ≠ 0).
            //Количество корней уравнения определять по значению дискриминанта: D = B2 − 4*A*C.
            try
            {
                string[] array2 = new string[3];
                using (StreamReader sr = File.OpenText("Input5.txt"))
                {
                    string input = null;
                    while ((input = sr.ReadLine()) != null)
                    {
                        array2 = input.Split('_');
                    }
                }
                double[] doubleArray1 = array2.Select(s => double.Parse(s)).ToArray();
                using (StreamWriter writer = File.CreateText("Output5.txt"))
                {
                    double A = doubleArray1[0];
                    double B = doubleArray1[1];
                    double C = doubleArray1[2];
                    if (A != 0)
                    {
                        int vivod5 = RootCount(A, B, C);
                        if (vivod5 == 1)
                        {
                            writer.WriteLine("2 корня");
                        }
                        else if (vivod5 == 0)
                        {
                            writer.WriteLine("1 корень");
                        }
                        else
                        {
                            writer.WriteLine("Корней нет!");
                        }
                    }
                    else
                    {
                        writer.WriteLine("число A не может быть 0!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Измените значения в файле!");
            }
            #endregion
        }
    }
}
