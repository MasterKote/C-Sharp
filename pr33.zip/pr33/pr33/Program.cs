﻿using System.Threading.Channels;

static int Max4(int A, int B, int C, int D)
{
    return Math.Min(A, Math.Min(B, Math.Min(C, D)));
}

//Задание 1
//Проверить истинность высказывания: "Среди трех данных целых положительны чисел введенных с клавиатуры,
//есть хотя бы одна пара совпадающих".

try
{
    Console.WriteLine("Задание 1");
m1:
    Console.WriteLine("Введите первое целое положительное число:");
    int digit1 = Convert.ToInt32(Console.ReadLine());
    if (digit1 <= 0)
    {
        goto m1;
    }
m2:
    Console.WriteLine("Введите второе целое положительное число:");
    int digit2 = Convert.ToInt32(Console.ReadLine());
    if (digit2 <= 0)
    {
        goto m2;
    }
m3:
    Console.WriteLine("Введите третье целое положительное число:");
    int digit3 = Convert.ToInt32(Console.ReadLine());
    if (digit3 <= 0)
    {
        goto m3;
    }

    if (digit1 == digit2 || digit2 == digit3 || digit1 == digit3)
    {
        Console.WriteLine("True");
    }
    else
    {
        Console.WriteLine("False"); ;
    }
}
catch(Exception ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine();

//Задание 2
//Даны пять целых ненулевых положительных чисел. Найти сумму двух наименьших чисел.

try
{
    Console.WriteLine("Задание 2");
    Console.WriteLine("Введите пять целых ненулевых положительных чисел");
    int[] intarr = new int[5];
    for (int i = 0; i < intarr.Length; i++)
    {
    m1_2:
        Console.WriteLine($"Введите {i + 1}-ое число");
        intarr[i] = Convert.ToInt32(Console.ReadLine());
        if (intarr[i] <= 0)
        {
            Console.WriteLine("целое ненулевое положительное!");
            goto m1_2;
        }
    }

    intarr.Sort();

    Console.WriteLine($"Сумма двух наименьших чисел: {intarr[0] + intarr[1]}");
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine();

//Задание 3
//Дан целочисленный массив, признак его завершения - число 0.
//Размер массива может быть разный. Вывести сумму всех положительных четных чисел из данного массива.
//Если требуемые числа в наборе отсутствуют, то вывести 0.

try
{
    Console.WriteLine("Задание 3");
    Console.WriteLine("Введите кол-во элементов массива(не менее 30):");

m1_3:
    int N = Convert.ToInt32(Console.ReadLine());
    if(N < 30)
    {
        Console.WriteLine("Не менее 30!");
        goto m1_3;
    }

    int[] intarr3 = new int[N];
    Random rand = new Random();

    for (int i = 0; i < N; i++)
    {
        intarr3[i] = rand.Next(-50, 50);
    }

    int sum = 0;
    for (int i = 0; i < N; i++)
    {
        if (intarr3[i] > 0 && intarr3[i] % 2 == 0)
        {
            sum += intarr3[i];
        }
    }

    if(sum == 0)
    {
        Console.WriteLine("0");
    }
    else
    {
        Console.WriteLine($"Сумма положительных чётных чисел: {sum}");
    }
}
catch(Exception ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine();

//Задание 4
//Написать функцию int Max4(A, B, C, D) целого типа,
//возвращающую одно максимальное значение из 4-х своих аргументов (параметры A, B, C и D - целые числа).

try
{
    Console.WriteLine("Задание 4");
    Console.WriteLine("Введите целое первое число:");
    int A = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Введите целое второе число:");
    int B = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Введите целое третье число:");
    int C = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Введите целое четвертое число:");
    int D = Convert.ToInt32(Console.ReadLine());

    int zad4min = Max4(A,B,C,D);
    Console.WriteLine($"Минимальное значение из 4-х чисел: {zad4min}");
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine();

//Задание 5
//Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
//Длина строки может быть разной.
//Строка содержит цифры и строчные латинские буквы.
//Если буквы в строке упорядочены по алфавиту, то вывести 0;
//в противном случае вывести номер первого символа строки, нарушающего алфавитный порядок.

try
{
    Console.WriteLine("Задание 5");
    Console.WriteLine("Введите строку: ");
    string input = Console.ReadLine();

    char lastLetter = '\0';
    bool broken = false;

    for (int i = 0; i < input.Length; i++)
    {
        char current = input[i];

        if (current >= 'a' && current <= 'z')
        {
            if (lastLetter != '\0' && current < lastLetter)
            {
                Console.WriteLine(i + 1);
                broken = true;
                break;
            }
            lastLetter = current;
        }
    }

    if (!broken)
    {
        Console.WriteLine(0);
    }
}
catch(Exception ex)
{
    Console.WriteLine(ex.Message);
}