﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR04
{
    internal class Program
    {
        static void Main(string[] args)
        {
        #region Задание 1
        M1:
            try
            {
                //Задание 1.
                //Даны два целых числа: A, B.
                //Проверить истинность высказывания: «Числа A и B имеют одинаковую четность».
                Console.WriteLine("Задание 1");

                int A = 0;
                Console.Write("Введите целое число A: ");
                A = Convert.ToInt32(Console.ReadLine());

                int B = 0;
                Console.Write("Введите целое число B: ");
                B = Convert.ToInt32(Console.ReadLine());

                bool A1 = false;
                bool B1 = false;

                if (A % 2 == 0)
                {
                    A1 = true;
                }
                if (B % 2 == 0)
                {
                    B1 = true;
                }
                if (A1 == true && B1 == true)
                {
                    Console.WriteLine("Оба числа чётные");
                }
                if (A1 == false && B1 == false)
                {
                    Console.WriteLine("Оба числа нечётные");
                }
                if (A1 == false && B1 == true || A1 == true && B1 == false)
                {
                    Console.WriteLine("Условие не выполняется");
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M1;
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
            }
            #endregion
            
            Console.WriteLine();

        #region Задание 2
        //Задание 2.
        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //Найти количество различных (не одинаковых) элементов в данном массиве.
        Console.WriteLine("Задание 2");

        M2:
            int discontcount = 0;
            int N = 0;

            Console.WriteLine("Введите число элементов массива, но не меньше 25!");
            N = Convert.ToInt32(Console.ReadLine());
            if (N < 25)
            {
                Console.WriteLine("Число элементов массива меньше 25!");
                goto M2;
            }
            int[] array = new int[N];
        M3:
            try
            {
                Console.WriteLine("Выберите как вы хотите заполнить массив: Введите 1 - автоматически, 2 - ручной ввод.");
                int Vvod = Convert.ToInt32(Console.ReadLine());
                switch (Vvod)
                {
                    case 1:
                        Random rand = new Random();
                        for (int i = 0; i < array.Length; i++)
                        {
                            array[i] = rand.Next(-50, 50);
                        }
                        break;
                    case 2:
                        for (int i = 0; i < array.Length; i++)
                        {

                            Console.Write("Введите число {0}: ", i + 1);
                        M4:
                            array[i] = 0;
                            try
                            {
                                array[i] = Convert.ToInt32(Console.ReadLine());
                            }
                            catch (OverflowException e)
                            {
                                Console.WriteLine(e.Message);
                                goto M4;
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine(e.Message);
                                goto M4;
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("Введено неверное значение!");
                        goto M3;
                }
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                goto M3;
            }
            Console.WriteLine("Массив:");
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + " ");
            }
            discontcount = array.Distinct().Count();

            Console.WriteLine("");
            Console.Write("Количество уникальных элементов: {0}", discontcount);
            #endregion
            
            Console.WriteLine("");
            Console.WriteLine("");

        #region Задание 3
            //Задание 3
            //Вводится строка. В строке могут быть любые символы.
            //Длина строки может быть разной.
            //Подсчитать и вывести количество содержащихся в этой строке цифр,
            //а так же сумму всех этих цифр.
            Console.WriteLine("Задание 3");

            int count = 0;
            int sum = 0;
            string str = "";
            Console.WriteLine("Введите любые символы");
            str = Console.ReadLine();

            Char[] chararray = str.ToCharArray();
            for (int i = 0; i < chararray.Length; i++)
            {
                if (Char.IsDigit(chararray[i]))
                {
                    sum += Convert.ToInt32(chararray[i].ToString());
                    count++;
                }
            }
            if (count == 0)
            {
                Console.WriteLine("В строке не обнаружено цифр");
            }
            else
            {
                Console.WriteLine("Число цифр в строке: {0}", count);
                Console.WriteLine("Сумма цифр в строке: {0}", sum);
            }
            #endregion
                
            Console.WriteLine("");

        #region Задание 4
            //Задание 4
            //Вводится строка, состоящая из букв и цифр (от 0 до 9).
            //Длина строки может быть разной.
            //Вывести сумму всех четных цифр встречающихся в этой строке.
            Console.WriteLine("Задание 4");

            int count1 = 0;
            int sum1 = 0;
            string str1 = "";
            Console.WriteLine("Введите строку состоящую из букв и цифр");
            str1 = Console.ReadLine();

            Char[] chararray1 = str1.ToCharArray();
            for (int i = 0;i < chararray1.Length;i++)
            {
                if (Char.IsDigit(chararray1[i]))
                {
                    if (Convert.ToInt32(chararray1[i].ToString()) % 2 == 0)
                    {
                        sum1 += Convert.ToInt32(chararray1[i].ToString());
                        count1++;
                    }
                }
            }
            if (count1 == 0)
            {
                Console.WriteLine("Чётных цифр в строке не обнаружено");
            }
            else
            {
                Console.Write("Сумма чётных цифр в строке: {0}", sum1);
            }
            #endregion

            Console.WriteLine("");
            Console.WriteLine("");

        #region Задание 5
            //Задание 5
            //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            //Требуется удалить из этой строки повторяющиеся символы.
            //Например, если было введено "abc_cde_defg",
            //то должно быть выведено "abcdefg".
            Console.WriteLine("Задание 5");

            string str2 = "";
            string str2_1 = "";
            Console.WriteLine("Введите любые символы:");
            str2 = Console.ReadLine();

            Char[] chararray2 = str2.ToCharArray();
            for (int i = 0; i < chararray2.Length;i++)
            {
                if (chararray2[i].ToString() != "_")
                {
                    str2_1 += chararray2[i].ToString();
                }
            }
            Console.WriteLine("");
            Console.WriteLine("Строка без нижних подчёркиваний:");
            Console.WriteLine(str2_1);

            Console.WriteLine("");

            Console.WriteLine("Нажмите на любую клавишу");
            Console.ReadKey();
            #endregion
        }
    }
}
