﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace pr_19
{
    internal class Program
    {
        static double Calc(double A1, double B1, int Op)
        {
            double result = 0;
            if (Op == 1)
            {
                result = A1 - B1;
            }
            else if (Op == 2)
            {
                result = A1 * B1;
            }
            else if (Op == 3)
            {
                result = A1 / B1;
            }
            else
            {
                result = A1 + B1;
            }

            return result;
        }
        static void Main(string[] args)
        {
            // Задание 1
            // Даны три целых числа: A, B, C.
            // Проверить истинность высказывания:
            // «Ровно одно из чисел A, B, C положительное».

            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input1.xml");

                XmlNodeList items = doc.GetElementsByTagName("pr_19");

                int A = 0;
                int B = 0;
                int C = 0;

                foreach (XmlNode item in items)
                {
                    A = Convert.ToInt32(item["ValueA"].InnerText);
                    B = Convert.ToInt32(item["ValueB"].InnerText);
                    C = Convert.ToInt32(item["ValueC"].InnerText);
                }
                if (A > 0 && B <= 0 && C <= 0)
                {
                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "«Только число A положительное»")));
                    string filePath = "output1.xml";
                    xdoc.Save(filePath);
                }
                else if (A <= 0 && B > 0 && C <= 0)
                {
                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "«Только число B положительное»")));
                    string filePath = "output1.xml";
                    xdoc.Save(filePath);
                }
                else if (A <= 0 && B <= 0 && C > 0)
                {
                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "«Только число C положительное»")));
                    string filePath = "output1.xml";
                    xdoc.Save(filePath);
                }
                else
                {
                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "«НЕТ ровно одного положительного из чисел A, B, C»")));
                    string filePath = "output1.xml";
                    xdoc.Save(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 2
            // Задано целое положительное четырехзначное число N (N > 0).
            // Найти разницу между произведениями первых двух и последних двух его цифр.

            try
            {
                XmlDocument doc1 = new XmlDocument();
                doc1.Load("input2.xml");

                XmlNodeList items1 = doc1.GetElementsByTagName("pr_19");

                int N = 0;

                foreach (XmlNode item in items1)
                {
                    N = Convert.ToInt32(item["ValueN"].InnerText);
                }

                if (N >= 1000 && N <= 9999)
                {
                    int digit1 = N / 1000;
                    int digit2 = (N / 100) % 10;
                    int digit3 = (N / 10) % 10;
                    int digit4 = N % 10;

                    int proizved1and2 = digit1 * digit2;
                    int proizved3and4 = digit3 * digit4;
                    int raznica = Math.Abs(proizved1and2 - proizved3and4);

                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", $"Разница между произведениями первых двух и последних двух его цифр = {raznica}")));
                    string filePath = "output2.xml";
                    xdoc.Save(filePath);
                }
                else
                {
                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "Число должно быть четырёхзначное!")));
                    string filePath = "output2.xml";
                    xdoc.Save(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 4
            // Написать функцию double Calc(A, B, Op) вещественного типа,
            // выполняющую над ненулевыми вещественными числами
            // A и B одну из арифметических операций и возвращающую ее результат.
            // Вид операции определяется целым параметром Op
            // : 1 — вычитание, 2 — умножение, 3 — деление, 4 — сложение.

            try
            {
                XmlDocument doc2 = new XmlDocument();
                doc2.Load("input4.xml");

                XmlNodeList items2 = doc2.GetElementsByTagName("pr_19");

                double A1 = 0;
                double B1 = 0;
                int Op = 0;

                foreach (XmlNode item in items2)
                {
                    A1 = Convert.ToDouble(item["ValueA1"].InnerText);
                    B1 = Convert.ToDouble(item["ValueB1"].InnerText);
                    Op = Convert.ToInt32(item["ValueOp"].InnerText);
                }

                if (Op >= 1 && Op <= 4)
                {
                    if (B1 == 0 && Op == 3)
                    {
                        XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "Деление на 0!")));
                        string filePath = "output4.xml";
                        xdoc.Save(filePath);
                    }
                    else
                    {
                        XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", $"Результат вычислений = {Calc(A1, B1, Op)}")));
                        string filePath = "output4.xml";
                        xdoc.Save(filePath);
                    }
                }
                else
                {
                    XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", "Выберите одну из данных арифметических операций!")));
                    string filePath = "output4.xml";
                    xdoc.Save(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 5
            // Вводится строка, содержащая цифры (от 0 до 9) и строчные латинские буквы.
            // Длина строки может быть разной.
            // Если цифры в строке упорядочены по возрастанию,
            // то вывести число 0;
            // в противном случае вывести номер первого символа строки, нарушающего порядок.

            try
            {
                XmlDocument doc3 = new XmlDocument();
                doc3.Load("input5.xml");

                XmlNodeList items3 = doc3.GetElementsByTagName("pr_19");

                string str = "";

                foreach (XmlNode item in items3)
                {
                    str = item["str"].InnerText;
                }

                int prevDigit = -1;
                int result = 0;

                for (int i = 0; i < str.Length; i++)
                {
                    char c = str[i];
                    if (char.IsDigit(c))
                    {
                        int currentDigit = c - '0';
                        if (currentDigit < prevDigit)
                        {
                            result = i + 1;
                            break;
                        }
                        prevDigit = currentDigit;
                    }
                }

                XDocument xdoc = new XDocument(new XElement("pr_19", new XElement("Result", result)));
                string filePath = "output5.xml";
                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
