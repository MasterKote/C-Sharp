﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace pr_17
{
    internal class Program
    {
        static void Main(string[] args)
        {
                //Создание подкаталога pr_17
                RegistryKey CurrentUser = Registry.CurrentUser;
                RegistryKey newKatalog = CurrentUser.CreateSubKey("pr_17");
                Console.WriteLine("Подкаталог {0} записан", newKatalog.Name);
                Console.WriteLine();

        //Задание 1
        //Проверить истинность высказывания:
        //"Среди трех данных целых положительны чисел введенных с клавиатуры,
        //есть хотя бы одна пара совпадающих".
        Z1:
            try
            {
                Console.WriteLine("Задание 1");
                RegistryKey task01 = newKatalog.CreateSubKey("task01");
            M1_1:
                Console.WriteLine("Введите первое целое положительное число");
                int digit1_1 = Convert.ToInt32(Console.ReadLine());
                if (digit1_1 > 0)
                {
                    task01.SetValue("Digit1_1", digit1_1);
                }
                else
                {
                    Console.WriteLine("Число должно целым положительным!");
                    goto M1_1;
                }

            M1_2:
                Console.WriteLine("Введите второе целое положительное число");
                int digit1_2 = Convert.ToInt32(Console.ReadLine());
                if (digit1_2 > 0)
                {
                    task01.SetValue("Digit1_2", digit1_2);
                }
                else
                {
                    Console.WriteLine("Число должно быть положительным!");
                    goto M1_2;
                }

            M1_3:
                Console.WriteLine("Введите третье целое положительное число");
                int digit1_3 = Convert.ToInt32(Console.ReadLine());
                if (digit1_3 > 0)
                {
                    task01.SetValue("Digit1_3", digit1_3);
                }
                else
                {
                    Console.WriteLine("Число должно быть положительным!");
                    goto M1_3;
                }
                if (digit1_1 == digit1_2 && digit1_1 == digit1_3 && digit1_2 == digit1_3)
                {
                    Console.WriteLine("Все числа равны");
                    task01.SetValue("result1", "Все числа равны");
                }
                else if (digit1_1 == digit1_3)
                {
                    Console.WriteLine("Первое число равно третьему");
                    task01.SetValue("result1", "Первое число равно третьему");
                }
                else if (digit1_2 == digit1_3)
                {
                    Console.WriteLine("Второе число равно третьему");
                    task01.SetValue("result1", "Второе число равно третьему");
                }
                else if (digit1_1 == digit1_2)
                {
                    Console.WriteLine("Первое число равно второму");
                    task01.SetValue("result1", "Первое число равно второму");
                }
                else
                {
                    Console.WriteLine("Нет равных чисел");
                    task01.SetValue("result1", "Нет равных чисел");
                }
                task01.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto Z1;
            }

            Console.WriteLine("");

        //Задание 2
        //Даны целые положительные числа A и B (A < B).
        //Вывести все целые числа от A до B включительно;
        //при этом каждое число должно выводиться столько раз,
        //каково его значение (например, число 3 выводится 3 раза).

        Z2:
            try
            {
                Console.WriteLine("Задание 2");
                RegistryKey task02 = newKatalog.CreateSubKey("task02");
            M2_1:
                Console.WriteLine("Введите целое положительное число A");
                int A1 = Convert.ToInt32(Console.ReadLine());
                if (A1 > 0)
                {
                    task02.SetValue("digit A", A1);
                }
                else
                {
                    Console.WriteLine("Число должно быть положительным!");
                    goto M2_1;
                }

            M2_2:
                Console.WriteLine("Введите целое положительное число B");
                int B1 = Convert.ToInt32(Console.ReadLine());
                if (B1 > 0)
                {
                    task02.SetValue("digit B", B1);
                }
                else
                {
                    Console.WriteLine("Число должно быть положительным!");
                    goto M2_2;
                }

                if (A1 > B1 || A1 == B1)
                {
                    Console.WriteLine("Число A должно быть меньше числа B");
                    goto M2_1;
                }

                Console.WriteLine();
                string result = "";
                for (int i = A1 + 1; i < B1; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write(i);
                        result += i.ToString();
                    }
                }
                task02.SetValue("result2", result);
                task02.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto Z2;
            }

            Console.WriteLine();

        //Задание 4
        //Написать функцию double Calc(A, B, Op) вещественного типа,
        //выполняющую над ненулевыми вещественными числами A и B одну из арифметических операций и возвращающую ее результат.
        //Вид операции определяется целым параметром Op: 1 — вычитание, 2 — умножение, 3 — деление, 4 — сложение.

        Z4:
            try
            {
                Console.WriteLine("Задание 4");
                RegistryKey task04 = newKatalog.CreateSubKey("task04");
            M4_1:
                Console.WriteLine("Введите ненулевое вещественное число A");
                double A2 = Convert.ToDouble(Console.ReadLine());
                if (A2 == 0)
                {
                    Console.WriteLine("Число должно быть ненулевым!");
                    goto M4_1;
                }
                else
                {
                    task04.SetValue("digit_A", A2);
                }

            M4_2:
                Console.WriteLine("Введите ненулевое вещественное число B");
                double B2 = Convert.ToDouble(Console.ReadLine());
                if (B2 == 0)
                {
                    Console.WriteLine("Число должно быть ненулевым!");
                    goto M4_2;
                }
                else
                {
                    task04.SetValue("digit_B", B2);
                }

            M4_3:
                Console.WriteLine("Выберите арифметическую операцию - <1 — вычитание, 2 — умножение, 3 — деление, 4 — сложение>");
                int Op = Convert.ToInt32(Console.ReadLine());
                if (Op == 1 || Op == 2 || Op == 3 || Op == 4)
                {
                    if (B2 == 0 && Op == 3)
                    {
                        Console.WriteLine("Деление на ноль невозможно!");
                        goto M4_3;
                    }
                    ArithmeticCalc arithmeticCalc = new ArithmeticCalc();
                    double result4 = arithmeticCalc.Calc(A2, B2, Op);
                    Console.WriteLine(result4);
                    task04.SetValue("result4", result4);
                }
                else
                {
                    Console.WriteLine("Неккоректный ввод");
                    goto M4_3;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto Z4;
            }

            Console.WriteLine();

        //Задание 5
        //Вводится строка,
        //изображающая целочисленное арифметическое выражение вида «цифра_цифра_цифра_цифра»,
        //где на месте знака операции «_» находится символ умножения - «*» или деления - «/»,
        //а на месте "цифра" находится одна из цифр (от 1 до 9).
        //Например, «4*8/3*5» результат равен 53.3.
        //Вывести значение данного выражения (как вещественное число).

        Z5:
            try
            {
                Console.WriteLine("Задание 5");
                RegistryKey task05 = newKatalog.CreateSubKey("task05");
                Console.WriteLine("Введите арифметическое выражение (например «4*8/3*5»)");
                string str = Convert.ToString(Console.ReadLine());
                task05.SetValue("input string", str);

                double result5 = str[0] - '0'; // Первая цифра

                for (int i = 1; i < str.Length; i++)
                {
                    if (str[i] == '*')
                    {
                        i++;
                        result5 *= str[i] - '0';
                    }
                    else if (str[i] == '/')
                    {
                        i++;
                        result5 /= str[i] - '0';
                    }
                }

                Console.WriteLine("Результат: {0}", result5);
                task05.SetValue("result", result5);
                task05.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto Z5;
            }

        }
        class ArithmeticCalc
        {
            public double Calc(double A, double B, int Op)
            {
                if (Op == 1)
                {
                    return A - B;
                }
                else if (Op == 2)
                {
                    return B * A;
                }
                else if (Op == 3)
                {
                    return A / B;
                }
                else if (Op == 4)
                {
                    return B + A;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
}
