import sys

#Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
#Требуется удалить из этой строки повторяющиеся символы.
#Например, если было введено "abc_cde_defg", то должно быть выведено "abcdefg".


def main():
    if len(sys.argv) != 2:
        print("Ошибка: необходимо ввести строку в кавычках.")
        return
    
    s = sys.argv[1]
    result = ""
    seen = set()
    
    for char in s:
        if char != '_' and char not in seen:
            result += char
            seen.add(char)
    
    print(result)

main()