import sys

#Дано целое положительное трехзначное число.
#В нем зачеркнули первую справа цифру и приписали ее слева. Вывести полученное новое число.

def main():
    if len(sys.argv) != 2:
        print("Ошибка: необходимо ввести одно трехзначное число.")
        return
    
    try:
        num = int(sys.argv[1])
    except ValueError:
        print("Ошибка: аргумент должен быть целым числом.")
        return
    
    if num < 100 or num > 999:
        print("Ошибка: число должно быть трехзначным (100-999).")
        return
    
    units = num % 10
    rest = num // 10
    new_num = units * 100 + rest
    
    print(new_num)

main()