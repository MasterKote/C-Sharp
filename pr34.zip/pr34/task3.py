import sys

#Дан целочисленный массив, состоящий из N элементов (N > 0, N может быть четным или нечетным числом).
#Поменять порядок следования его элементов на обратный.
#Вычислить и вывести сумму и произведение всех его элементов.

def main():
    if len(sys.argv) < 2:
        print("Ошибка: необходимо ввести размер массива и его элементы.")
        return
    
    try:
        n = int(sys.argv[1])
        if n <= 0:
            print("Ошибка: размер массива N должен быть > 0.")
            return
        
        if len(sys.argv) != n + 2:
            print(f"Ошибка: ожидается {n} элементов, но получено {len(sys.argv) - 2}.")
            return
        
        arr = list(map(int, sys.argv[2:2+n]))
    except ValueError:
        print("Ошибка: все элементы должны быть целыми числами.")
        return
    
    reversed_arr = arr[::-1]
    total_sum = sum(arr)
    total_product = 1
    for num in arr:
        total_product *= num
    
    print("Развернутый массив:", reversed_arr)
    print("Сумма элементов:", total_sum)
    print("Произведение элементов:", total_product)

main()