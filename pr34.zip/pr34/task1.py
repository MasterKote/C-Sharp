import sys

#Даны три целых числа: A, B, C.
#Проверить истинность высказывания: «Ровно одно из чисел A, B, C положительное».

def main():
    if len(sys.argv) != 4:
        print("Необходимо ввести три числа.")
        return

    try:
        a, b, c = map(int, sys.argv[1:4])
    except ValueError:
        print("Все аргументы должны быть целыми числами.")
        return
    
    positive_count = 0
    if a > 0:
        positive_count += 1
    if b > 0:
        positive_count += 1
    if c > 0:
        positive_count += 1
    
    result = positive_count == 1
    print(result)

main()